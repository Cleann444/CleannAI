#pragma once
// ────────────────────────────────────────────────────────────────────────────
// inference.h – TensorRT / ONNX inference engine (optimized)
// ────────────────────────────────────────────────────────────────────────────
#include <NvInfer.h>
#include <NvOnnxParser.h>
#include <cuda_runtime.h>

#include <atomic>
#include <filesystem>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

// ── Detection result ──────────────────────────────────────────────────────
struct Detection {
    float x, y, w, h;          // centre-x, centre-y, width, height (pixels in capture space)
    float confidence;
    int   classId;
};

// ── TensorRT logger ───────────────────────────────────────────────────────
class TrtLogger : public nvinfer1::ILogger {
public:
    void log(Severity severity, const char* msg) noexcept override;
};

// ── Inference Engine ──────────────────────────────────────────────────────
class InferenceEngine {
public:
    InferenceEngine();
    ~InferenceEngine();

    // Enumerate CUDA devices
    static std::vector<std::string> enumerateGPUs();

    // Select CUDA device before loading model
    bool selectGPU(int deviceIndex);
    int  currentGPU() const { return gpuIndex_; }

    // Load an ONNX file (auto-converts to TRT), or a .trt engine directly.
    // precision: "FP32", "FP16", "INT8"
    bool loadModel(const std::filesystem::path& path,
                   int inputSize,
                   const std::string& precision = "FP16");

    // Run inference on BGRA pixel buffer.
    // Returns detections in capture-space coordinates.
    bool infer(const uint8_t* bgraData, int width, int height,
               float confThresh, float nmsThresh,
               std::vector<Detection>& out);

    bool   isReady()   const { return ready_.load(); }
    float  lastMs()    const { return lastInferMs_; }
    int    inputSize() const { return inputSize_; }

private:
    TrtLogger logger_;
    int gpuIndex_ = 0;
    int inputSize_ = 640;

    // TensorRT objects (unique_ptr with custom deleters)
    struct TrtDeleter { void operator()(nvinfer1::IRuntime* p)            { delete p; } };
    struct EngDeleter { void operator()(nvinfer1::ICudaEngine* p)         { delete p; } };
    struct CtxDeleter { void operator()(nvinfer1::IExecutionContext* p)   { delete p; } };

    std::unique_ptr<nvinfer1::IRuntime, TrtDeleter>          runtime_;
    std::unique_ptr<nvinfer1::ICudaEngine, EngDeleter>       engine_;
    std::unique_ptr<nvinfer1::IExecutionContext, CtxDeleter>  context_;

    // CUDA device buffers
    void* d_input_  = nullptr;
    void* d_output_ = nullptr;

    // Pinned host buffers (for async DMA transfers – avoids GPU stalls)
    void* h_input_  = nullptr;
    void* h_output_ = nullptr;

    size_t inputBytes_  = 0;
    size_t outputBytes_ = 0;
    cudaStream_t stream_ = nullptr;

    std::atomic<bool> ready_{false};
    float lastInferMs_ = 0.f;

    bool buildEngineFromOnnx(const std::filesystem::path& onnxPath,
                             const std::filesystem::path& trtPath,
                             int inputSize,
                             const std::string& precision);
    bool loadEngineFile(const std::filesystem::path& trtPath);
    bool allocateBuffers();
    void freeBuffers();

    // Post-process raw TensorRT output → detections
    void postProcess(const float* rawOutput, int numDetections,
                     float confThresh, float nmsThresh,
                     std::vector<Detection>& out);
    void nms(std::vector<Detection>& dets, float nmsThresh);
};
