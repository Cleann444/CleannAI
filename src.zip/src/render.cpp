// ────────────────────────────────────────────────────────────────────────────
// render.cpp – 1 box per detection, keyed by tracking ID. No stacking.
// ────────────────────────────────────────────────────────────────────────────
#include "render.h"
#include <cmath>
#include <algorithm>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

const std::vector<BoneConnection>& OverlayRenderer::boneConnections() {
    static const std::vector<BoneConnection> conns = {
        {J_HEAD,       J_NECK},
        {J_NECK,       J_CHEST},
        {J_CHEST,      J_HIP_CENTER},
        {J_NECK,       J_LSHOULDER},
        {J_LSHOULDER,  J_LELBOW},
        {J_LELBOW,     J_LWRIST},
        {J_NECK,       J_RSHOULDER},
        {J_RSHOULDER,  J_RELBOW},
        {J_RELBOW,     J_RWRIST},
        {J_HIP_CENTER, J_LHIP},
        {J_LHIP,       J_LKNEE},
        {J_LKNEE,      J_LANKLE},
        {J_HIP_CENTER, J_RHIP},
        {J_RHIP,       J_RKNEE},
        {J_RKNEE,      J_RANKLE},
    };
    return conns;
}

OverlayRenderer::OverlayRenderer()
    : lastUpdate_(std::chrono::steady_clock::now()) {}

// ── Update boxes — 1:1 map from tracked target ID to SmoothedBox ─────────
void OverlayRenderer::updateBoxes(const std::vector<TrackedTarget>& targets,
                                    float captureX, float captureY,
                                    float /*smoothAlpha*/) {
    auto now = std::chrono::steady_clock::now();

    // Build set of active IDs from this frame's targets
    std::unordered_set<int> activeIds;
    for (const auto& t : targets) {
        if (t.lostFrames == 0)
            activeIds.insert(t.id);
    }

    // Update existing boxes or insert new ones
    for (const auto& t : targets) {
        if (t.lostFrames > 0) continue;  // skip lost targets

        float newX = captureX + t.det.x - t.det.w / 2.f;
        float newY = captureY + t.det.y - t.det.h / 2.f;
        float newW = t.det.w;
        float newH = t.det.h;

        auto it = boxMap_.find(t.id);
        if (it != boxMap_.end()) {
            // Existing box — snap to new position
            auto& sb = it->second;
            sb.x = newX;
            sb.y = newY;
            sb.w = newW;
            sb.h = newH;
            sb.tx = newX;
            sb.ty = newY;
            sb.tw = newW;
            sb.th = newH;
            sb.confidence = t.det.confidence;
            sb.classId = t.det.classId;
            sb.alpha = 1.f;
            sb.alive = true;
            sb.lastSeen = now;
        } else {
            // New box
            SmoothedBox sb;
            sb.x = newX;
            sb.y = newY;
            sb.w = newW;
            sb.h = newH;
            sb.tx = newX;
            sb.ty = newY;
            sb.tw = newW;
            sb.th = newH;
            sb.alpha = 1.f;
            sb.maxAlpha = 1.f;
            sb.id = t.id;
            sb.confidence = t.det.confidence;
            sb.classId = t.det.classId;
            sb.alive = true;
            sb.lastSeen = now;
            sb.created = now;
            boxMap_[t.id] = sb;
        }
    }

    // Remove boxes whose ID is no longer in the active set
    for (auto it = boxMap_.begin(); it != boxMap_.end(); ) {
        if (activeIds.find(it->first) == activeIds.end()) {
            it = boxMap_.erase(it);
        } else {
            ++it;
        }
    }

    lastUpdate_ = now;
}

// ── Interpolate — build skeletons from current boxes ─────────────────────
void OverlayRenderer::interpolateBoxes(float /*dt*/) {
    skeletons_.clear();
    for (const auto& [id, sb] : boxMap_) {
        skeletons_.push_back(estimateSkeleton(sb));
    }
}

// ── Draw ─────────────────────────────────────────────────────────────────
void OverlayRenderer::draw(ImDrawList* drawList,
                             float screenCx, float screenCy,
                             float fovRadius,
                             int activeTargetId,
                             const RenderSettings& settings) {
    if (!drawList) return;

    if (settings.showFov) {
        drawFovCircle(drawList, screenCx, screenCy, fovRadius,
                       settings.rainbowFov, settings.glowIntensity,
                       settings.glowPasses);
    }

    if (settings.showBoxes) {
        for (const auto& [id, sb] : boxMap_) {
            float boxCx = sb.x + sb.w / 2.f;
            float boxCy = sb.y + sb.h / 2.f;
            float dx = boxCx - screenCx;
            float dy = boxCy - screenCy;
            float dist = std::sqrt(dx * dx + dy * dy);
            if (dist > fovRadius + (std::max)(sb.w, sb.h)) continue;

            bool isTarget = (sb.id == activeTargetId);
            drawBox(drawList, sb, isTarget, settings);
        }
    }

    if (settings.showSkeleton) {
        for (const auto& skel : skeletons_) {
            float skelCx = skel.joints[J_CHEST].x;
            float skelCy = skel.joints[J_CHEST].y;
            float dx = skelCx - screenCx;
            float dy = skelCy - screenCy;
            if (std::sqrt(dx * dx + dy * dy) > fovRadius + 150.f) continue;

            drawSkeleton(drawList, skel, settings);
        }
    }
}

// ── Draw box (no glow pulsing — solid lines) ─────────────────────────────
void OverlayRenderer::drawBox(ImDrawList* dl, const SmoothedBox& box,
                                bool isTarget, const RenderSettings& settings) {
    const auto& colorArr = isTarget ? settings.targetColor : settings.boxColor;
    ImU32 mainColor = ImGui::ColorConvertFloat4ToU32(
        ImVec4(colorArr[0], colorArr[1], colorArr[2], colorArr[3]));

    ImVec2 tl(box.x, box.y);
    ImVec2 br(box.x + box.w, box.y + box.h);

    // Simple glow (static, no pulsing)
    int passes = settings.glowPasses;
    for (int i = passes; i >= 1; --i) {
        float expand = static_cast<float>(i) * 1.5f;
        float ga = colorArr[3] * settings.glowIntensity * (1.f / static_cast<float>(i + 1));
        ImU32 gc = ImGui::ColorConvertFloat4ToU32(
            ImVec4(colorArr[0], colorArr[1], colorArr[2], ga));
        dl->AddRect(ImVec2(tl.x - expand, tl.y - expand),
                     ImVec2(br.x + expand, br.y + expand), gc, 0.f, 0, 1.0f);
    }

    // Main box
    dl->AddRect(tl, br, mainColor, 0.f, 0, 2.0f);

    // Corner brackets
    float cornerLen = (std::max)(8.f, (std::min)(box.w, box.h) * 0.2f);
    ImU32 cornerColor = ImGui::ColorConvertFloat4ToU32(
        ImVec4((std::min)(1.f, colorArr[0] * 1.3f),
               (std::min)(1.f, colorArr[1] * 1.3f),
               (std::min)(1.f, colorArr[2] * 1.3f),
               colorArr[3]));

    dl->AddLine(tl, ImVec2(tl.x + cornerLen, tl.y), cornerColor, 2.5f);
    dl->AddLine(tl, ImVec2(tl.x, tl.y + cornerLen), cornerColor, 2.5f);
    dl->AddLine(ImVec2(br.x, tl.y), ImVec2(br.x - cornerLen, tl.y), cornerColor, 2.5f);
    dl->AddLine(ImVec2(br.x, tl.y), ImVec2(br.x, tl.y + cornerLen), cornerColor, 2.5f);
    dl->AddLine(ImVec2(tl.x, br.y), ImVec2(tl.x + cornerLen, br.y), cornerColor, 2.5f);
    dl->AddLine(ImVec2(tl.x, br.y), ImVec2(tl.x, br.y - cornerLen), cornerColor, 2.5f);
    dl->AddLine(br, ImVec2(br.x - cornerLen, br.y), cornerColor, 2.5f);
    dl->AddLine(br, ImVec2(br.x, br.y - cornerLen), cornerColor, 2.5f);

    // Confidence label
    if (settings.showConfidence && box.confidence > 0.f) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%.0f%%", box.confidence * 100.f);
        ImVec2 textPos(tl.x, tl.y - 16.f);
        dl->AddText(ImVec2(textPos.x + 1, textPos.y + 1),
                     IM_COL32(0, 0, 0, 180), buf);
        dl->AddText(textPos, IM_COL32(255, 255, 255, 230), buf);
    }
}

// ── Stickman skeleton from box proportions ───────────────────────────────
SkeletonPose OverlayRenderer::estimateSkeleton(const SmoothedBox& box) const {
    SkeletonPose pose;
    pose.id = box.id;
    pose.alpha = 1.f;

    float cx = box.x + box.w * 0.5f;
    float top = box.y;

    float headY     = top + box.h * 0.06f;
    float neckY     = top + box.h * 0.15f;
    float chestY    = top + box.h * 0.30f;
    float hipY      = top + box.h * 0.52f;
    float kneeY     = top + box.h * 0.75f;
    float ankleY    = top + box.h * 0.98f;

    float shoulderW = box.w * 0.35f;
    float hipW      = box.w * 0.22f;

    pose.joints[J_HEAD]       = {cx, headY};
    pose.joints[J_NECK]       = {cx, neckY};
    pose.joints[J_CHEST]      = {cx, chestY};
    pose.joints[J_LSHOULDER]  = {cx - shoulderW, neckY + box.h * 0.03f};
    pose.joints[J_RSHOULDER]  = {cx + shoulderW, neckY + box.h * 0.03f};
    pose.joints[J_LELBOW]     = {cx - shoulderW * 1.1f, chestY + box.h * 0.08f};
    pose.joints[J_RELBOW]     = {cx + shoulderW * 1.1f, chestY + box.h * 0.08f};
    pose.joints[J_LWRIST]     = {cx - shoulderW * 0.9f, hipY - box.h * 0.02f};
    pose.joints[J_RWRIST]     = {cx + shoulderW * 0.9f, hipY - box.h * 0.02f};
    pose.joints[J_HIP_CENTER] = {cx, hipY};
    pose.joints[J_LHIP]       = {cx - hipW, hipY + box.h * 0.02f};
    pose.joints[J_RHIP]       = {cx + hipW, hipY + box.h * 0.02f};
    pose.joints[J_LKNEE]      = {cx - hipW * 0.9f, kneeY};
    pose.joints[J_RKNEE]      = {cx + hipW * 0.9f, kneeY};
    pose.joints[J_LANKLE]     = {cx - hipW * 0.7f, ankleY};
    pose.joints[J_RANKLE]     = {cx + hipW * 0.7f, ankleY};

    return pose;
}

// ── Draw skeleton — just lines + head circle, no joint dots ──────────────
void OverlayRenderer::drawSkeleton(ImDrawList* dl, const SkeletonPose& skel,
                                     const RenderSettings& settings) {
    const auto& conns = boneConnections();

    ImU32 boneColor = ImGui::ColorConvertFloat4ToU32(
        ImVec4(settings.skeletonColor[0], settings.skeletonColor[1],
               settings.skeletonColor[2], settings.skeletonColor[3]));
    ImU32 shadowColor = IM_COL32(0, 0, 0, 100);

    for (const auto& conn : conns) {
        if (conn.from == J_HEAD && conn.to == J_NECK) continue;

        auto& from = skel.joints[conn.from];
        auto& to   = skel.joints[conn.to];

        dl->AddLine(ImVec2(from.x + 1.f, from.y + 1.f),
                     ImVec2(to.x + 1.f, to.y + 1.f),
                     shadowColor, settings.skeletonThick);
        dl->AddLine(ImVec2(from.x, from.y),
                     ImVec2(to.x, to.y),
                     boneColor, settings.skeletonThick);
    }

    // Head circle only
    float headRadius = (std::max)(6.f, skel.joints[J_NECK].y - skel.joints[J_HEAD].y);
    dl->AddCircle(ImVec2(skel.joints[J_HEAD].x + 1.f, skel.joints[J_HEAD].y + 1.f),
                   headRadius, shadowColor, 16, settings.skeletonThick);
    dl->AddCircle(ImVec2(skel.joints[J_HEAD].x, skel.joints[J_HEAD].y),
                   headRadius, boneColor, 16, settings.skeletonThick);
}

// ── FOV circle ───────────────────────────────────────────────────────────
void OverlayRenderer::drawFovCircle(ImDrawList* dl,
                                       float cx, float cy, float r,
                                       bool rainbow, float glowIntensity,
                                       int glowPasses) {
    ImU32 circleColor;
    if (rainbow) {
        hue_ += 0.005f;
        if (hue_ > 1.f) hue_ -= 1.f;
        ImVec4 hsv;
        ImGui::ColorConvertHSVtoRGB(hue_, 0.9f, 1.0f, hsv.x, hsv.y, hsv.z);
        hsv.w = 0.6f;
        circleColor = ImGui::ColorConvertFloat4ToU32(hsv);
    } else {
        circleColor = IM_COL32(0, 255, 200, 100);
    }

    for (int i = glowPasses; i >= 1; --i) {
        float expand = static_cast<float>(i) * 2.f;
        float alpha  = glowIntensity * (0.2f / static_cast<float>(i));
        ImVec4 c = ImGui::ColorConvertU32ToFloat4(circleColor);
        c.w *= alpha;
        dl->AddCircle(ImVec2(cx, cy), r + expand,
                       ImGui::ColorConvertFloat4ToU32(c), 64, 1.0f);
    }
    dl->AddCircle(ImVec2(cx, cy), r, circleColor, 64, 1.5f);
}
