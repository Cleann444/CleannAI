#pragma once
// ────────────────────────────────────────────────────────────────────────────
// render.h – DX11 overlay rendering: live ESP boxes, skeleton, FOV circle
// ────────────────────────────────────────────────────────────────────────────
#include "inference.h"
#include "aimbot.h"

#include <imgui.h>
#include <d3d11.h>
#include <vector>
#include <array>
#include <chrono>
#include <unordered_map>
#include <unordered_set>

// ── Smoothed bounding box for rendering (keyed by tracking ID) ───────────
struct SmoothedBox {
    float x, y, w, h;          // current screen-space position
    float tx, ty, tw, th;      // target position (latest detection)
    float vx = 0.f, vy = 0.f;  // estimated velocity (px/s)
    float alpha    = 0.f;       // current opacity
    float maxAlpha = 1.f;       // target opacity
    int   id       = -1;        // tracking ID
    int   classId  = 0;
    float confidence = 0.f;
    bool  alive    = true;      // still detected this cycle
    std::chrono::steady_clock::time_point lastSeen;
    std::chrono::steady_clock::time_point created;
};

// ── Skeleton joint estimated from bounding box ────────────────────────────
struct SkeletonJoint {
    float x, y;
};

struct SkeletonPose {
    // 17 joints: head, neck, l/r shoulder, l/r elbow, l/r wrist,
    //            hip_center, l/r hip, l/r knee, l/r ankle, chest
    SkeletonJoint joints[17];
    int   id;
    float alpha;
};

// Joint indices
enum JointIdx {
    J_HEAD = 0, J_NECK, J_CHEST,
    J_LSHOULDER, J_RSHOULDER,
    J_LELBOW, J_RELBOW,
    J_LWRIST, J_RWRIST,
    J_HIP_CENTER,
    J_LHIP, J_RHIP,
    J_LKNEE, J_RKNEE,
    J_LANKLE, J_RANKLE,
    J_COUNT
};

// Bone connection pair for drawing
struct BoneConnection {
    int from, to;
};

// ── Render settings ──────────────────────────────────────────────────────
struct RenderSettings {
    bool  showFov         = true;
    bool  rainbowFov      = false;
    bool  showBoxes       = true;
    bool  showSkeleton    = true;      // skeleton ESP toggle
    bool  showConfidence  = true;      // show confidence % label
    float boxSmoothAlpha  = 0.35f;     // EMA alpha (higher = snappier)
    float glowIntensity   = 0.40f;     // reduced from 0.6 for perf
    int   glowPasses      = 2;         // reduced from 4 for perf
    float skeletonThick   = 2.0f;      // skeleton line thickness
    float boxFadeInSpeed  = 8.0f;      // alpha/s fade in rate
    float boxFadeOutSpeed = 3.0f;      // alpha/s fade out rate
    float boxPersistTime  = 0.5f;      // seconds to keep showing after lost
    std::array<float,4> boxColor    = {0.f, 1.f, 0.5f, 0.86f};
    std::array<float,4> targetColor = {1.f, 0.2f, 0.2f, 0.94f};
    std::array<float,4> skeletonColor = {0.2f, 0.9f, 1.0f, 0.8f};
};

// ── Overlay Renderer ─────────────────────────────────────────────────────
class OverlayRenderer {
public:
    OverlayRenderer();

    // Update smoothed boxes from tracked targets (call once per inference tick)
    void updateBoxes(const std::vector<TrackedTarget>& targets,
                     float captureX, float captureY,
                     float smoothAlpha);

    // Interpolate boxes forward in time (call every render frame for smooth ESP)
    void interpolateBoxes(float dt);

    // Draw all overlay elements using ImGui's draw list
    void draw(ImDrawList* drawList,
              float screenCx, float screenCy,
              float fovRadius,
              int   activeTargetId,
              const RenderSettings& settings);

private:
    // 1:1 map — exactly one SmoothedBox per tracking ID, no duplicates ever
    std::unordered_map<int, SmoothedBox> boxMap_;
    std::vector<SkeletonPose>            skeletons_;
    float hue_ = 0.f;

    std::chrono::steady_clock::time_point lastUpdate_;
    bool firstUpdate_ = true;

    // Internal draw helpers
    void drawBox(ImDrawList* dl, const SmoothedBox& box,
                 bool isTarget, const RenderSettings& settings);
    void drawSkeleton(ImDrawList* dl, const SkeletonPose& skel,
                      const RenderSettings& settings);
    void drawFovCircle(ImDrawList* dl, float cx, float cy, float r,
                       bool rainbow, float glowIntensity, int glowPasses);

    // Estimate skeleton from bounding box
    SkeletonPose estimateSkeleton(const SmoothedBox& box) const;

    // Static bone connections
    static const std::vector<BoneConnection>& boneConnections();
};
