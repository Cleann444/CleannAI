#pragma once
// ────────────────────────────────────────────────────────────────────────────
// input.h – SendInput mouse movement + hotkey polling
// ────────────────────────────────────────────────────────────────────────────
#include <Windows.h>
#include <string>
#include <vector>

// Supported activation keys
enum class ActivationKey {
    RightClick, Mouse4, Mouse5, MiddleClick,
    Alt, Ctrl, Shift
};

inline const char* activationKeyName(ActivationKey k) {
    switch (k) {
        case ActivationKey::RightClick:  return "Right Click";
        case ActivationKey::Mouse4:      return "Mouse4";
        case ActivationKey::Mouse5:      return "Mouse5";
        case ActivationKey::MiddleClick: return "Middle Click";
        case ActivationKey::Alt:         return "Alt";
        case ActivationKey::Ctrl:        return "Ctrl";
        case ActivationKey::Shift:       return "Shift";
    }
    return "Right Click";
}

inline ActivationKey activationKeyFromName(const std::string& name) {
    if (name == "Mouse4")       return ActivationKey::Mouse4;
    if (name == "Mouse5")       return ActivationKey::Mouse5;
    if (name == "Middle Click") return ActivationKey::MiddleClick;
    if (name == "Alt")          return ActivationKey::Alt;
    if (name == "Ctrl")         return ActivationKey::Ctrl;
    if (name == "Shift")        return ActivationKey::Shift;
    return ActivationKey::RightClick;
}

class InputManager {
public:
    // Move mouse by relative delta using SendInput
    static void moveMouse(int dx, int dy);

    // Check if the activation key is currently held
    static bool isActivationHeld(ActivationKey key);

    // Check if F1 was pressed (toggle)
    static bool wasTogglePressed();
};
