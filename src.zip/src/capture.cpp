// ────────────────────────────────────────────────────────────────────────────
// capture.cpp – DXGI Desktop Duplication screen capture
// ────────────────────────────────────────────────────────────────────────────
#include "capture.h"
#include <chrono>
#include <algorithm>
#include <vector>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

// ── TripleBuffer ──────────────────────────────────────────────────────────

CapturedFrame& TripleBuffer::writeBuffer() {
    return buffers_[writeIdx_.load(std::memory_order_relaxed)];
}

void TripleBuffer::publishWrite() {
    int w = writeIdx_.load(std::memory_order_relaxed);
    int r = readyIdx_.exchange(w, std::memory_order_acq_rel);
    writeIdx_.store(r, std::memory_order_release);
    fresh_.store(true, std::memory_order_release);
}

bool TripleBuffer::newFrameAvailable() const {
    return fresh_.load(std::memory_order_acquire);
}

CapturedFrame& TripleBuffer::readBuffer() {
    if (fresh_.load(std::memory_order_acquire)) {
        int rd = readIdx_.load(std::memory_order_relaxed);
        int rdy = readyIdx_.exchange(rd, std::memory_order_acq_rel);
        readIdx_.store(rdy, std::memory_order_release);
        fresh_.store(false, std::memory_order_release);
    }
    return buffers_[readIdx_.load(std::memory_order_relaxed)];
}

// ── ScreenCapture ─────────────────────────────────────────────────────────

ScreenCapture::ScreenCapture() = default;

ScreenCapture::~ScreenCapture() {
    shutdown();
}

bool ScreenCapture::init(int gpuIndex) {
    // Create DXGI factory
    ComPtr<IDXGIFactory1> factory;
    if (FAILED(CreateDXGIFactory1(IID_PPV_ARGS(&factory))))
        return false;

    // Enumerate adapters and pick the requested GPU
    ComPtr<IDXGIAdapter1> adapter;
    if (FAILED(factory->EnumAdapters1(gpuIndex, &adapter)))
        return false;

    // Create D3D11 device on the chosen adapter
    D3D_FEATURE_LEVEL featureLevel = D3D_FEATURE_LEVEL_11_0;
    UINT flags = 0;
#ifdef _DEBUG
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

    HRESULT hr = D3D11CreateDevice(
        adapter.Get(),
        D3D_DRIVER_TYPE_UNKNOWN,
        nullptr,
        flags,
        &featureLevel, 1,
        D3D11_SDK_VERSION,
        &device_, nullptr, &ctx_
    );
    if (FAILED(hr)) return false;

    // Get the primary output
    ComPtr<IDXGIOutput> output;
    if (FAILED(adapter->EnumOutputs(0, &output)))
        return false;

    ComPtr<IDXGIOutput1> output1;
    if (FAILED(output.As(&output1)))
        return false;

    // Get output (monitor) description for screen dimensions
    DXGI_OUTPUT_DESC desc;
    output->GetDesc(&desc);
    screenW_ = desc.DesktopCoordinates.right  - desc.DesktopCoordinates.left;
    screenH_ = desc.DesktopCoordinates.bottom - desc.DesktopCoordinates.top;

    // Create duplication
    hr = output1->DuplicateOutput(device_.Get(), &dup_);
    if (FAILED(hr)) return false;

    return true;
}

void ScreenCapture::shutdown() {
    dup_.Reset();
    staging_.Reset();
    ctx_.Reset();
    device_.Reset();
}

bool ScreenCapture::createStagingTexture(int size) {
    if (lastCaptureSize_ == size && staging_)
        return true;

    staging_.Reset();

    D3D11_TEXTURE2D_DESC desc = {};
    desc.Width              = size;
    desc.Height             = size;
    desc.MipLevels          = 1;
    desc.ArraySize          = 1;
    desc.Format             = DXGI_FORMAT_B8G8R8A8_UNORM;
    desc.SampleDesc.Count   = 1;
    desc.Usage              = D3D11_USAGE_STAGING;
    desc.CPUAccessFlags     = D3D11_CPU_ACCESS_READ;

    HRESULT hr = device_->CreateTexture2D(&desc, nullptr, &staging_);
    if (FAILED(hr)) return false;

    lastCaptureSize_ = size;
    return true;
}

bool ScreenCapture::captureRegion(int captureSize) {
    if (!dup_) return false;

    // Acquire next frame (1ms timeout for high-freq polling)
    ComPtr<IDXGIResource> resource;
    DXGI_OUTDUPL_FRAME_INFO frameInfo;
    HRESULT hr = dup_->AcquireNextFrame(1, &frameInfo, &resource);

    if (hr == DXGI_ERROR_WAIT_TIMEOUT)
        return false;

    if (FAILED(hr)) {
        // Recreate duplication on access lost
        dup_.Reset();
        return false;
    }

    // Get the desktop texture
    ComPtr<ID3D11Texture2D> desktopTex;
    hr = resource.As(&desktopTex);
    if (FAILED(hr)) {
        dup_->ReleaseFrame();
        return false;
    }

    // Ensure staging texture exists
    if (!createStagingTexture(captureSize)) {
        dup_->ReleaseFrame();
        return false;
    }

    // Copy the centre region from the desktop texture
    int srcX = (screenW_ - captureSize) / 2;
    int srcY = (screenH_ - captureSize) / 2;
    srcX = (std::max)(0, srcX);
    srcY = (std::max)(0, srcY);

    D3D11_BOX box;
    box.left   = srcX;
    box.top    = srcY;
    box.right  = (std::min)(srcX + captureSize, screenW_);
    box.bottom = (std::min)(srcY + captureSize, screenH_);
    box.front  = 0;
    box.back   = 1;

    ctx_->CopySubresourceRegion(staging_.Get(), 0, 0, 0, 0,
                                 desktopTex.Get(), 0, &box);

    // Map the staging texture
    D3D11_MAPPED_SUBRESOURCE mapped;
    hr = ctx_->Map(staging_.Get(), 0, D3D11_MAP_READ, 0, &mapped);
    if (FAILED(hr)) {
        dup_->ReleaseFrame();
        return false;
    }

    int actualW = box.right  - box.left;
    int actualH = box.bottom - box.top;
    size_t rowBytes = actualW * 4;

    // Write into triple buffer
    auto& frame = buffer_.writeBuffer();
    frame.width  = actualW;
    frame.height = actualH;
    frame.pixels.resize(rowBytes * actualH);

    LARGE_INTEGER qpc;
    QueryPerformanceCounter(&qpc);
    frame.timestamp = qpc.QuadPart;

    // Copy row by row (pitch may differ)
    const uint8_t* src = static_cast<const uint8_t*>(mapped.pData);
    for (int y = 0; y < actualH; ++y) {
        memcpy(frame.pixels.data() + y * rowBytes,
               src + y * mapped.RowPitch,
               rowBytes);
    }

    ctx_->Unmap(staging_.Get(), 0);
    dup_->ReleaseFrame();

    buffer_.publishWrite();
    return true;
}
