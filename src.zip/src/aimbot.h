#pragma once
// ────────────────────────────────────────────────────────────────────────────
// aimbot.h – Aim logic: flick + anti-sway + deceleration curve
// ────────────────────────────────────────────────────────────────────────────
#include "inference.h"
#include <chrono>
#include <deque>
#include <optional>

// ── Target bone offset ────────────────────────────────────────────────────
enum class TargetBone { Head, Neck, Chest };

inline const char* boneName(TargetBone b) {
    switch (b) {
        case TargetBone::Head:  return "Head";
        case TargetBone::Neck:  return "Neck";
        case TargetBone::Chest: return "Chest";
    }
    return "Head";
}

// ── Tracked target with velocity history ──────────────────────────────────
struct TrackedTarget {
    Detection det;
    float     aimX, aimY;                       // aim-point in screen coords
    float     velX = 0.f, velY = 0.f;           // px/s estimated velocity (EMA-smoothed)
    int       id        = -1;                   // tracking ID (spatial match)
    int       lostFrames = 0;
    int       age       = 0;                    // frames since first seen
    float     smoothedConfidence = 0.f;         // EMA-smoothed confidence

    using Clock = std::chrono::high_resolution_clock;
    Clock::time_point lastUpdateTime;
};

// ── Aim output ────────────────────────────────────────────────────────────
struct AimResult {
    bool  shouldAim = false;
    float deltaX    = 0.f;                     // mouse move delta X
    float deltaY    = 0.f;                     // mouse move delta Y
    int   targetIdx = -1;                      // index into tracked targets
};

// ── Aim settings ──────────────────────────────────────────────────────────
struct AimSettings {
    bool       enabled       = true;
    float      fovRadius     = 200.f;
    bool       stickyAim     = false;
    bool       antiOvershoot = true;
    float      aiSpeed       = 5.f;            // 1-20 slider
    float      smoothFactor  = 0.35f;
    float      sensitivity   = 1.0f;           // mouse sensitivity multiplier
    bool       predictionEnabled = true;       // velocity prediction toggle
    float      predictionStrength = 0.5f;      // 0-1 how much to extrapolate
    TargetBone bone          = TargetBone::Head;
};

// ── Aimbot ────────────────────────────────────────────────────────────────
class Aimbot {
public:
    Aimbot();

    // Update tracking only (no aim computation) — for ESP display
    void updateTracking(const std::vector<Detection>& dets,
                        float captureX, float captureY,
                        TargetBone bone);

    // Compute aim delta for the best target within FOV
    AimResult computeAim(float screenCx, float screenCy,
                         const AimSettings& settings);

    const std::vector<TrackedTarget>& trackedTargets() const { return tracked_; }
    int stickyId() const { return stickyId_; }

private:
    std::vector<TrackedTarget> tracked_;
    int   nextId_        = 1;
    int   stickyId_      = -1;

    // Sub-pixel accumulation (prevents stalling near target)
    float accumX_        = 0.f;
    float accumY_        = 0.f;

    // Oscillation detection: track error sign history
    float prevErrorX_    = 0.f;
    float prevErrorY_    = 0.f;
    int   signFlipCountX_ = 0;      // consecutive X sign flips
    int   signFlipCountY_ = 0;      // consecutive Y sign flips

    // Global screen shift detection (filters out player strafe)
    float prevGlobalShiftX_ = 0.f;
    float prevGlobalShiftY_ = 0.f;

    using Clock = std::chrono::high_resolution_clock;
    Clock::time_point lastTime_;
    Clock::time_point lastTrackingTime_;

    // Choose the best target
    int selectTarget(float screenCx, float screenCy, float fovRadius, bool sticky);

    // Anti-overshoot
    void applyAntiOvershoot(float& dx, float& dy,
                            float errorX, float errorY);

    // Compute IoU between two detections
    static float computeIoU(const Detection& a, const Detection& b);
};
