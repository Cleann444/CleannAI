// ────────────────────────────────────────────────────────────────────────────
// aimbot.cpp – Flick aim with anti-sway (strafe oscillation fix)
//
//   ROOT CAUSE OF SWAY: When the player strafes left/right, ALL targets
//   shift on screen in the same direction. The aimbot reads this as
//   "target moved" and tries to correct — but by the time the correction
//   lands, the player has moved MORE, so the target has shifted again.
//   This creates an oscillation loop: left-right-left-right.
//
//   THREE FIXES APPLIED:
//   1. GLOBAL SHIFT FILTER: If all tracked targets shift in the same
//      direction between frames, that's player movement, not target
//      movement. We subtract this global shift from velocity estimation
//      so prediction doesn't amplify the sway.
//   2. OSCILLATION DAMPENER: If the error keeps flipping sign (left,
//      right, left, right), we progressively reduce correction strength
//      to break the feedback loop.
//   3. AXIS-INDEPENDENT CORRECTION: X and Y are corrected separately
//      with independent oscillation tracking, so vertical aim (which
//      doesn't sway during strafing) stays aggressive.
// ────────────────────────────────────────────────────────────────────────────
#include "aimbot.h"
#include <cmath>
#include <algorithm>
#include <limits>
#include <vector>

Aimbot::Aimbot()
    : lastTime_(Clock::now()), lastTrackingTime_(Clock::now()) {}

float Aimbot::computeIoU(const Detection& a, const Detection& b) {
    float ax1 = a.x - a.w / 2.f, ay1 = a.y - a.h / 2.f;
    float ax2 = a.x + a.w / 2.f, ay2 = a.y + a.h / 2.f;
    float bx1 = b.x - b.w / 2.f, by1 = b.y - b.h / 2.f;
    float bx2 = b.x + b.w / 2.f, by2 = b.y + b.h / 2.f;

    float ix1 = (std::max)(ax1, bx1), iy1 = (std::max)(ay1, by1);
    float ix2 = (std::min)(ax2, bx2), iy2 = (std::min)(ay2, by2);
    float inter = (std::max)(0.f, ix2 - ix1) * (std::max)(0.f, iy2 - iy1);
    float unionA = a.w * a.h + b.w * b.h - inter;
    return unionA > 0.f ? inter / unionA : 0.f;
}

// ── Update tracking (call once per frame) ────────────────────────────────
void Aimbot::updateTracking(const std::vector<Detection>& dets,
                              float captureX, float captureY,
                              TargetBone bone) {
    float boneRatio;
    switch (bone) {
        case TargetBone::Head:  boneRatio = 0.10f; break;
        case TargetBone::Neck:  boneRatio = 0.25f; break;
        case TargetBone::Chest: boneRatio = 0.40f; break;
        default:                boneRatio = 0.10f; break;
    }

    auto now = Clock::now();
    float trackDt = std::chrono::duration<float>(now - lastTrackingTime_).count();
    lastTrackingTime_ = now;

    if (dets.empty()) {
        for (auto& t : tracked_)
            t.lostFrames++;
        for (auto it = tracked_.begin(); it != tracked_.end(); ) {
            if (it->lostFrames > 30)
                it = tracked_.erase(it);
            else
                ++it;
        }
        return;
    }

    // Mark all as lost
    for (auto& t : tracked_)
        t.lostFrames++;

    std::vector<bool> detUsed(dets.size(), false);

    // ── Compute global screen shift (player strafe detection) ────────
    // If multiple targets all shifted in the same direction, that's
    // the player moving, not the targets. We'll subtract this from
    // per-target velocity so prediction doesn't amplify the sway.
    float globalShiftX = 0.f, globalShiftY = 0.f;
    int shiftCount = 0;

    // First pass: compute shifts for IoU-matched targets
    struct MatchInfo { size_t trackIdx; int detIdx; float shiftX; float shiftY; };
    std::vector<MatchInfo> matches;

    for (size_t ti = 0; ti < tracked_.size(); ++ti) {
        auto& track = tracked_[ti];
        float bestScore = 0.15f;
        int bestJ = -1;
        for (size_t j = 0; j < dets.size(); ++j) {
            if (detUsed[j]) continue;
            float s = computeIoU(track.det, dets[j]);
            if (s > bestScore) { bestScore = s; bestJ = static_cast<int>(j); }
        }
        if (bestJ >= 0) {
            detUsed[bestJ] = true;
            const auto& d = dets[bestJ];
            float newAimX = captureX + d.x;
            float newAimY = captureY + (d.y - d.h / 2.f) + d.h * boneRatio;

            float sx = newAimX - track.aimX;
            float sy = newAimY - track.aimY;
            globalShiftX += sx;
            globalShiftY += sy;
            shiftCount++;

            matches.push_back({ti, bestJ, sx, sy});
        }
    }

    // Average global shift
    if (shiftCount > 0) {
        globalShiftX /= shiftCount;
        globalShiftY /= shiftCount;
    }

    // EMA the global shift to avoid noise
    prevGlobalShiftX_ = prevGlobalShiftX_ * 0.5f + globalShiftX * 0.5f;
    prevGlobalShiftY_ = prevGlobalShiftY_ * 0.5f + globalShiftY * 0.5f;

    // ── Apply matched updates with corrected velocity ────────────────
    for (const auto& m : matches) {
        auto& track = tracked_[m.trackIdx];
        const auto& d = dets[m.detIdx];
        float newAimX = captureX + d.x;
        float newAimY = captureY + (d.y - d.h / 2.f) + d.h * boneRatio;

        // Velocity = per-target shift MINUS global shift (removes strafe)
        if (trackDt > 0.001f && trackDt < 0.2f) {
            float rawVelX = (newAimX - track.aimX) / trackDt;
            float rawVelY = (newAimY - track.aimY) / trackDt;
            // Subtract global motion (player strafe) from velocity
            float correctedVelX = rawVelX - (prevGlobalShiftX_ / (std::max)(trackDt, 0.001f));
            float correctedVelY = rawVelY - (prevGlobalShiftY_ / (std::max)(trackDt, 0.001f));
            // EMA smooth the corrected velocity
            track.velX = track.velX * 0.6f + correctedVelX * 0.4f;
            track.velY = track.velY * 0.6f + correctedVelY * 0.4f;
        }

        track.det  = d;
        track.aimX = newAimX;
        track.aimY = newAimY;
        track.lostFrames = 0;
        track.age++;
        track.smoothedConfidence = d.confidence;
        track.lastUpdateTime = now;
    }

    // Pass 2: Distance match for unmatched tracks
    for (auto& track : tracked_) {
        if (track.lostFrames == 0) continue;
        float bestDist = 100.f;
        int bestJ = -1;
        for (size_t j = 0; j < dets.size(); ++j) {
            if (detUsed[j]) continue;
            float sx = captureX + dets[j].x;
            float sy = captureY + dets[j].y;
            float dx = sx - track.aimX;
            float dy = sy - track.aimY;
            float dist = std::sqrt(dx * dx + dy * dy);
            if (dist < bestDist) { bestDist = dist; bestJ = static_cast<int>(j); }
        }
        if (bestJ >= 0) {
            detUsed[bestJ] = true;
            const auto& d = dets[bestJ];
            float newAimX = captureX + d.x;
            float newAimY = captureY + (d.y - d.h / 2.f) + d.h * boneRatio;
            if (trackDt > 0.001f && trackDt < 0.2f) {
                float rawVelX = (newAimX - track.aimX) / trackDt;
                float rawVelY = (newAimY - track.aimY) / trackDt;
                float correctedVelX = rawVelX - (prevGlobalShiftX_ / (std::max)(trackDt, 0.001f));
                float correctedVelY = rawVelY - (prevGlobalShiftY_ / (std::max)(trackDt, 0.001f));
                track.velX = track.velX * 0.6f + correctedVelX * 0.4f;
                track.velY = track.velY * 0.6f + correctedVelY * 0.4f;
            }
            track.det  = d;
            track.aimX = newAimX;
            track.aimY = newAimY;
            track.lostFrames = 0;
            track.age++;
            track.smoothedConfidence = d.confidence;
            track.lastUpdateTime = now;
        }
    }

    // New tracks
    for (size_t j = 0; j < dets.size(); ++j) {
        if (detUsed[j]) continue;
        const auto& d = dets[j];
        TrackedTarget nt;
        nt.det  = d;
        nt.aimX = captureX + d.x;
        nt.aimY = captureY + (d.y - d.h / 2.f) + d.h * boneRatio;
        nt.id   = nextId_++;
        nt.lostFrames = 0;
        nt.age = 1;
        nt.smoothedConfidence = d.confidence;
        nt.lastUpdateTime = now;
        tracked_.push_back(nt);
    }

    // Prune
    for (auto it = tracked_.begin(); it != tracked_.end(); ) {
        if (it->lostFrames > 30)
            it = tracked_.erase(it);
        else
            ++it;
    }
}

// ── Compute aim with deceleration curve + anti-sway ──────────────────────
AimResult Aimbot::computeAim(float screenCx, float screenCy,
                               const AimSettings& settings) {
    AimResult result;
    if (!settings.enabled) return result;

    int bestIdx = selectTarget(screenCx, screenCy,
                                settings.fovRadius, settings.stickyAim);
    if (bestIdx < 0) return result;

    result.targetIdx = bestIdx;
    const auto& target = tracked_[bestIdx];

    // ── Raw error: where the target IS relative to crosshair ─────────
    float errorX = target.aimX - screenCx;
    float errorY = target.aimY - screenCy;

    // ── Velocity prediction (now strafe-filtered) ────────────────────
    if (settings.predictionEnabled) {
        auto now = Clock::now();
        float dt = std::chrono::duration<float>(now - lastTime_).count();
        lastTime_ = now;
        if (dt > 0.f && dt < 0.1f) {
            // target.velX/velY already have global shift subtracted,
            // so this only predicts REAL target movement, not strafe.
            errorX += target.velX * dt * settings.predictionStrength;
            errorY += target.velY * dt * settings.predictionStrength;
        }
    }

    // ── Oscillation detection (per-axis) ─────────────────────────────
    // If the error keeps flipping sign, we're in a sway loop.
    // Count consecutive sign flips and dampen proportionally.

    // X-axis oscillation
    if (std::abs(errorX) > 1.0f && std::abs(prevErrorX_) > 1.0f) {
        if (std::signbit(errorX) != std::signbit(prevErrorX_)) {
            signFlipCountX_ = (std::min)(signFlipCountX_ + 1, 10);
        } else {
            signFlipCountX_ = (std::max)(signFlipCountX_ - 2, 0);
        }
    } else {
        signFlipCountX_ = (std::max)(signFlipCountX_ - 1, 0);
    }

    // Y-axis oscillation
    if (std::abs(errorY) > 1.0f && std::abs(prevErrorY_) > 1.0f) {
        if (std::signbit(errorY) != std::signbit(prevErrorY_)) {
            signFlipCountY_ = (std::min)(signFlipCountY_ + 1, 10);
        } else {
            signFlipCountY_ = (std::max)(signFlipCountY_ - 2, 0);
        }
    } else {
        signFlipCountY_ = (std::max)(signFlipCountY_ - 1, 0);
    }

    prevErrorX_ = errorX;
    prevErrorY_ = errorY;

    // Oscillation dampening: more flips = more dampening
    // 0 flips → 1.0 (no dampening), 5+ flips → 0.15 (heavy dampening)
    float dampX = 1.0f / (1.0f + signFlipCountX_ * 0.6f);
    float dampY = 1.0f / (1.0f + signFlipCountY_ * 0.6f);

    // ── Per-axis deceleration + oscillation dampening ────────────────
    float maxSpeed = settings.aiSpeed * settings.sensitivity;
    float brakeRadius = settings.smoothFactor * 200.f;

    // X-axis
    float absErrX = std::abs(errorX);
    float speedScaleX;
    if (absErrX >= brakeRadius) {
        speedScaleX = 1.0f;
    } else {
        float t = absErrX / brakeRadius;
        speedScaleX = t * t;
    }
    float moveX = (errorX > 0.f ? 1.f : -1.f) * (std::min)(maxSpeed * speedScaleX * dampX, absErrX);

    // Y-axis
    float absErrY = std::abs(errorY);
    float speedScaleY;
    if (absErrY >= brakeRadius) {
        speedScaleY = 1.0f;
    } else {
        float t = absErrY / brakeRadius;
        speedScaleY = t * t;
    }
    float moveY = (errorY > 0.f ? 1.f : -1.f) * (std::min)(maxSpeed * speedScaleY * dampY, absErrY);

    // ── Dead zone ────────────────────────────────────────────────────
    if (std::abs(moveX) < 0.01f && std::abs(moveY) < 0.01f)
        return result;

    // ── Sub-pixel accumulation ───────────────────────────────────────
    accumX_ += moveX;
    accumY_ += moveY;

    float intPartX, intPartY;
    float fracX = std::modf(accumX_, &intPartX);
    float fracY = std::modf(accumY_, &intPartY);

    accumX_ = fracX;
    accumY_ = fracY;

    if (static_cast<int>(intPartX) == 0 && static_cast<int>(intPartY) == 0)
        return result;

    result.shouldAim = true;
    result.deltaX    = intPartX;
    result.deltaY    = intPartY;
    return result;
}

// ── Target selection ─────────────────────────────────────────────────────
int Aimbot::selectTarget(float screenCx, float screenCy,
                           float fovRadius, bool sticky) {
    if (sticky && stickyId_ >= 0) {
        for (size_t i = 0; i < tracked_.size(); ++i) {
            if (tracked_[i].id == stickyId_ && tracked_[i].lostFrames == 0)
                return static_cast<int>(i);
        }
        stickyId_ = -1;
    }

    float bestDist = std::numeric_limits<float>::max();
    int bestIdx = -1;

    for (size_t i = 0; i < tracked_.size(); ++i) {
        if (tracked_[i].lostFrames > 0) continue;
        float dx = tracked_[i].aimX - screenCx;
        float dy = tracked_[i].aimY - screenCy;
        float dist = std::sqrt(dx * dx + dy * dy);
        if (dist > fovRadius) continue;
        if (dist < bestDist) {
            bestDist = dist;
            bestIdx  = static_cast<int>(i);
        }
    }

    if (bestIdx >= 0 && sticky)
        stickyId_ = tracked_[bestIdx].id;

    return bestIdx;
}

// ── Anti-overshoot (legacy, kept for compatibility) ──────────────────────
void Aimbot::applyAntiOvershoot(float& dx, float& dy,
                                  float errorX, float errorY) {
    if (std::abs(dx) > std::abs(errorX))
        dx = errorX;
    if (std::abs(dy) > std::abs(errorY))
        dy = errorY;

    if (errorX != 0.f && std::signbit(dx) != std::signbit(errorX))
        dx = 0.f;
    if (errorY != 0.f && std::signbit(dy) != std::signbit(errorY))
        dy = 0.f;
}
