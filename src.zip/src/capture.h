#pragma once
// ────────────────────────────────────────────────────────────────────────────
// capture.h – DXGI Desktop Duplication screen capture
// ────────────────────────────────────────────────────────────────────────────
#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>

#include <atomic>
#include <array>
#include <cstdint>
#include <mutex>
#include <vector>

using Microsoft::WRL::ComPtr;

// Raw captured frame (BGRA pixels, region around crosshair)
struct CapturedFrame {
    std::vector<uint8_t> pixels;   // BGRA
    int                  width  = 0;
    int                  height = 0;
    int64_t              timestamp = 0; // QPC ticks
};

// ── Triple-buffer for lock-free producer/consumer ─────────────────────────
class TripleBuffer {
public:
    CapturedFrame& writeBuffer();
    void           publishWrite();          // flip write → ready
    bool           newFrameAvailable() const;
    CapturedFrame& readBuffer();            // flips ready → read
private:
    std::array<CapturedFrame, 3> buffers_;
    std::atomic<int> writeIdx_{0};
    std::atomic<int> readyIdx_{1};
    std::atomic<int> readIdx_{2};
    std::atomic<bool> fresh_{false};
};

// ── Screen Capture ────────────────────────────────────────────────────────
class ScreenCapture {
public:
    ScreenCapture();
    ~ScreenCapture();

    bool init(int gpuIndex = 0);
    void shutdown();

    // Capture a square region centred on screen. Returns false on timeout.
    bool captureRegion(int captureSize);

    TripleBuffer& tripleBuffer() { return buffer_; }

    int screenWidth()  const { return screenW_; }
    int screenHeight() const { return screenH_; }

private:
    ComPtr<ID3D11Device>           device_;
    ComPtr<ID3D11DeviceContext>    ctx_;
    ComPtr<IDXGIOutputDuplication> dup_;
    ComPtr<ID3D11Texture2D>        staging_;

    TripleBuffer buffer_;
    int screenW_ = 0, screenH_ = 0;
    int lastCaptureSize_ = 0;

    bool createStagingTexture(int size);
};
