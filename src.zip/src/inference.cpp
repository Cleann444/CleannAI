// ────────────────────────────────────────────────────────────────────────────
// inference.cpp – TensorRT / ONNX inference engine (fixed ONNX loading)
// ────────────────────────────────────────────────────────────────────────────
#include "inference.h"

#include <fstream>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <cassert>
#include <chrono>
#include <filesystem>

// ── TrtLogger ─────────────────────────────────────────────────────────────

void TrtLogger::log(Severity severity, const char* msg) noexcept {
    // Log ALL messages during model loading for debugging
    if (severity <= Severity::kINFO)
        std::cerr << "[TRT] " << msg << "\n";
}

// ── Helpers ───────────────────────────────────────────────────────────────

static float iou(const Detection& a, const Detection& b) {
    float ax1 = a.x - a.w / 2, ay1 = a.y - a.h / 2;
    float ax2 = a.x + a.w / 2, ay2 = a.y + a.h / 2;
    float bx1 = b.x - b.w / 2, by1 = b.y - b.h / 2;
    float bx2 = b.x + b.w / 2, by2 = b.y + b.h / 2;

    float ix1 = (std::max)(ax1, bx1), iy1 = (std::max)(ay1, by1);
    float ix2 = (std::min)(ax2, bx2), iy2 = (std::min)(ay2, by2);
    float inter = (std::max)(0.f, ix2 - ix1) * (std::max)(0.f, iy2 - iy1);
    float unionA = a.w * a.h + b.w * b.h - inter;
    return unionA > 0.f ? inter / unionA : 0.f;
}

// ── InferenceEngine ───────────────────────────────────────────────────────

InferenceEngine::InferenceEngine() {
    cudaStreamCreate(&stream_);
}

InferenceEngine::~InferenceEngine() {
    freeBuffers();
    if (stream_) cudaStreamDestroy(stream_);
}

std::vector<std::string> InferenceEngine::enumerateGPUs() {
    int count = 0;
    cudaGetDeviceCount(&count);
    std::vector<std::string> names;
    for (int i = 0; i < count; ++i) {
        cudaDeviceProp prop;
        cudaGetDeviceProperties(&prop, i);
        names.push_back(std::string(prop.name));
    }
    return names;
}

bool InferenceEngine::selectGPU(int deviceIndex) {
    if (cudaSetDevice(deviceIndex) != cudaSuccess)
        return false;
    gpuIndex_ = deviceIndex;
    return true;
}

bool InferenceEngine::loadModel(const std::filesystem::path& path,
                                 int inputSize,
                                 const std::string& precision) {
    ready_.store(false);
    freeBuffers();
    engine_.reset();
    context_.reset();
    runtime_.reset();

    inputSize_ = inputSize;

    // Validate path exists
    if (!std::filesystem::exists(path)) {
        std::cerr << "[Cleann] Model file not found: " << path << "\n";
        return false;
    }

    std::cerr << "[Cleann] Loading model: " << path << " (size=" << inputSize
              << ", precision=" << precision << ")\n";

    std::filesystem::path trtPath;

    if (path.extension() == ".onnx") {
        // Build TRT cache path next to ONNX file
        trtPath = path;
        trtPath.replace_extension(
            "." + std::to_string(inputSize) + "." + precision + ".trt");

        if (!std::filesystem::exists(trtPath)) {
            std::cerr << "[Cleann] Building TensorRT engine from ONNX "
                      << "(this may take several minutes)...\n";
            if (!buildEngineFromOnnx(path, trtPath, inputSize, precision)) {
                std::cerr << "[Cleann] ERROR: Failed to build engine from ONNX\n";
                return false;
            }
            std::cerr << "[Cleann] Engine built and saved to: " << trtPath << "\n";
        } else {
            std::cerr << "[Cleann] Loading cached TRT engine: " << trtPath << "\n";
            if (!loadEngineFile(trtPath)) {
                std::cerr << "[Cleann] ERROR: Failed to load cached engine, rebuilding...\n";
                // Delete stale cache and rebuild
                std::filesystem::remove(trtPath);
                if (!buildEngineFromOnnx(path, trtPath, inputSize, precision))
                    return false;
            }
        }
    } else if (path.extension() == ".trt" || path.extension() == ".engine") {
        if (!loadEngineFile(path)) {
            std::cerr << "[Cleann] ERROR: Failed to load engine file\n";
            return false;
        }
    } else {
        std::cerr << "[Cleann] ERROR: Unsupported file format: "
                  << path.extension() << "\n";
        return false;
    }

    if (!allocateBuffers()) {
        std::cerr << "[Cleann] ERROR: Failed to allocate GPU buffers\n";
        return false;
    }

    ready_.store(true);
    std::cerr << "[Cleann] Model loaded successfully!\n";
    return true;
}

bool InferenceEngine::buildEngineFromOnnx(const std::filesystem::path& onnxPath,
                                           const std::filesystem::path& trtPath,
                                           int inputSize,
                                           const std::string& precision) {
    auto builder = std::unique_ptr<nvinfer1::IBuilder>(
        nvinfer1::createInferBuilder(logger_));
    if (!builder) {
        std::cerr << "[Cleann] ERROR: createInferBuilder failed\n";
        return false;
    }

    uint32_t batchFlag = 1U << static_cast<uint32_t>(
        nvinfer1::NetworkDefinitionCreationFlag::kEXPLICIT_BATCH);
    auto network = std::unique_ptr<nvinfer1::INetworkDefinition>(
        builder->createNetworkV2(batchFlag));
    if (!network) {
        std::cerr << "[Cleann] ERROR: createNetworkV2 failed\n";
        return false;
    }

    auto parser = std::unique_ptr<nvonnxparser::IParser>(
        nvonnxparser::createParser(*network, logger_));
    if (!parser) {
        std::cerr << "[Cleann] ERROR: createParser failed\n";
        return false;
    }

    // Use verbose logging for ONNX parsing to see errors
    std::cerr << "[Cleann] Parsing ONNX file: " << onnxPath << "\n";
    bool parseOk = parser->parseFromFile(
        onnxPath.string().c_str(),
        static_cast<int>(nvinfer1::ILogger::Severity::kINFO));

    if (!parseOk) {
        std::cerr << "[Cleann] ERROR: ONNX parsing failed!\n";
        // Print specific parser errors
        int numErrors = parser->getNbErrors();
        for (int i = 0; i < numErrors; ++i) {
            auto err = parser->getError(i);
            std::cerr << "[Cleann] Parser error " << i << ": "
                      << err->desc() << "\n";
        }
        return false;
    }

    std::cerr << "[Cleann] ONNX parsed OK. Network has "
              << network->getNbInputs() << " inputs, "
              << network->getNbOutputs() << " outputs\n";

    // Print input/output tensor info
    for (int i = 0; i < network->getNbInputs(); ++i) {
        auto inp = network->getInput(i);
        auto dims = inp->getDimensions();
        std::cerr << "[Cleann]   Input[" << i << "] \"" << inp->getName()
                  << "\" dims=[";
        for (int d = 0; d < dims.nbDims; ++d)
            std::cerr << dims.d[d] << (d < dims.nbDims - 1 ? "," : "");
        std::cerr << "]\n";
    }
    for (int i = 0; i < network->getNbOutputs(); ++i) {
        auto out = network->getOutput(i);
        auto dims = out->getDimensions();
        std::cerr << "[Cleann]   Output[" << i << "] \"" << out->getName()
                  << "\" dims=[";
        for (int d = 0; d < dims.nbDims; ++d)
            std::cerr << dims.d[d] << (d < dims.nbDims - 1 ? "," : "");
        std::cerr << "]\n";
    }

    auto config = std::unique_ptr<nvinfer1::IBuilderConfig>(
        builder->createBuilderConfig());
    if (!config) return false;

    config->setMemoryPoolLimit(nvinfer1::MemoryPoolType::kWORKSPACE,
                                1ULL << 30);

    if (precision == "FP16" && builder->platformHasFastFp16())
        config->setFlag(nvinfer1::BuilderFlag::kFP16);
    if (precision == "INT8" && builder->platformHasFastInt8())
        config->setFlag(nvinfer1::BuilderFlag::kINT8);

    // Only add optimization profile if the input has dynamic shapes
    auto inputTensor = network->getInput(0);
    auto inputDims = inputTensor->getDimensions();
    bool hasDynamic = false;
    for (int d = 0; d < inputDims.nbDims; ++d) {
        if (inputDims.d[d] == -1) { hasDynamic = true; break; }
    }

    if (hasDynamic) {
        auto profile = builder->createOptimizationProfile();
        auto inputName = inputTensor->getName();
        nvinfer1::Dims4 dims{1, 3, inputSize, inputSize};
        profile->setDimensions(inputName,
                                nvinfer1::OptProfileSelector::kMIN, dims);
        profile->setDimensions(inputName,
                                nvinfer1::OptProfileSelector::kOPT, dims);
        profile->setDimensions(inputName,
                                nvinfer1::OptProfileSelector::kMAX, dims);
        config->addOptimizationProfile(profile);
        std::cerr << "[Cleann] Added dynamic shape profile for " << inputName << "\n";
    }

    std::cerr << "[Cleann] Building engine (this can take 1-10 minutes)...\n";
    auto serialised = std::unique_ptr<nvinfer1::IHostMemory>(
        builder->buildSerializedNetwork(*network, *config));
    if (!serialised) {
        std::cerr << "[Cleann] ERROR: buildSerializedNetwork failed\n";
        return false;
    }

    // Save to disk
    std::ofstream file(trtPath, std::ios::binary);
    if (!file) {
        std::cerr << "[Cleann] ERROR: Cannot write to " << trtPath << "\n";
        return false;
    }
    file.write(static_cast<const char*>(serialised->data()), serialised->size());
    file.close();

    return loadEngineFile(trtPath);
}

bool InferenceEngine::loadEngineFile(const std::filesystem::path& trtPath) {
    std::ifstream file(trtPath, std::ios::binary | std::ios::ate);
    if (!file) return false;

    size_t size = file.tellg();
    file.seekg(0);
    std::vector<char> data(size);
    file.read(data.data(), size);

    runtime_.reset(nvinfer1::createInferRuntime(logger_));
    if (!runtime_) return false;

    engine_.reset(runtime_->deserializeCudaEngine(data.data(), size));
    if (!engine_) return false;

    context_.reset(engine_->createExecutionContext());
    if (!context_) return false;

    return true;
}

bool InferenceEngine::allocateBuffers() {
    if (!engine_) return false;

    int inputIdx = 0;
    auto inputName = engine_->getIOTensorName(inputIdx);

    // Check if we need to set input shape
    auto currentDims = engine_->getTensorShape(inputName);
    bool needsShape = false;
    for (int d = 0; d < currentDims.nbDims; ++d) {
        if (currentDims.d[d] == -1) { needsShape = true; break; }
    }

    if (needsShape) {
        nvinfer1::Dims4 dims{1, 3, inputSize_, inputSize_};
        context_->setInputShape(inputName, dims);
    }

    inputBytes_ = 1 * 3 * inputSize_ * inputSize_ * sizeof(float);
    cudaMalloc(&d_input_, inputBytes_);

    // Find the output tensor
    int numIO = engine_->getNbIOTensors();
    int outputIdx = -1;
    for (int i = 0; i < numIO; ++i) {
        auto name = engine_->getIOTensorName(i);
        if (engine_->getTensorIOMode(name) == nvinfer1::TensorIOMode::kOUTPUT) {
            outputIdx = i;
            break;
        }
    }
    if (outputIdx < 0) {
        std::cerr << "[Cleann] ERROR: No output tensor found\n";
        return false;
    }

    auto outputName = engine_->getIOTensorName(outputIdx);
    auto outputDims = context_->getTensorShape(outputName);

    std::cerr << "[Cleann] Output tensor \"" << outputName << "\" dims=[";
    for (int d = 0; d < outputDims.nbDims; ++d)
        std::cerr << outputDims.d[d] << (d < outputDims.nbDims - 1 ? "," : "");
    std::cerr << "]\n";

    outputBytes_ = 1;
    for (int i = 0; i < outputDims.nbDims; ++i)
        outputBytes_ *= (std::max)(static_cast<size_t>(1), static_cast<size_t>(outputDims.d[i]));
    outputBytes_ *= sizeof(float);

    outputBytes_ = (std::max)(outputBytes_, size_t(1 * 25200 * 85 * sizeof(float)));
    cudaMalloc(&d_output_, outputBytes_);

    cudaMallocHost(&h_input_, inputBytes_);
    cudaMallocHost(&h_output_, outputBytes_);

    context_->setTensorAddress(inputName,  d_input_);
    context_->setTensorAddress(outputName, d_output_);

    return true;
}

void InferenceEngine::freeBuffers() {
    if (d_input_)  { cudaFree(d_input_);  d_input_  = nullptr; }
    if (d_output_) { cudaFree(d_output_); d_output_ = nullptr; }
    if (h_input_)  { cudaFreeHost(h_input_);  h_input_  = nullptr; }
    if (h_output_) { cudaFreeHost(h_output_); h_output_ = nullptr; }
}

bool InferenceEngine::infer(const uint8_t* bgraData, int width, int height,
                             float confThresh, float nmsThresh,
                             std::vector<Detection>& out) {
    if (!ready_.load()) return false;

    auto t0 = std::chrono::high_resolution_clock::now();

    int inS = inputSize_;
    float* inputBlob = static_cast<float*>(h_input_);
    int planeSize = inS * inS;
    float* planeR = inputBlob;
    float* planeG = inputBlob + planeSize;
    float* planeB = inputBlob + planeSize * 2;

    constexpr float inv255 = 1.f / 255.f;

    if (width == inS && height == inS) {
        // FAST PATH: capture matches input — no resize needed
        // Process 1 pixel per iteration, straight sequential access
        int totalPixels = inS * inS;
        const uint8_t* px = bgraData;
        for (int i = 0; i < totalPixels; ++i, px += 4) {
            planeR[i] = px[2] * inv255;
            planeG[i] = px[1] * inv255;
            planeB[i] = px[0] * inv255;
        }
    } else {
        // RESIZE PATH: nearest-neighbor sampling
        // Pre-compute X lookup table to avoid per-pixel multiply
        float scaleX = static_cast<float>(width)  / inS;
        float scaleY = static_cast<float>(height) / inS;

        std::vector<int> xLut(inS);
        for (int x = 0; x < inS; ++x)
            xLut[x] = (std::min)(static_cast<int>(x * scaleX), width - 1) * 4;

        for (int y = 0; y < inS; ++y) {
            int srcY = (std::min)(static_cast<int>(y * scaleY), height - 1);
            const uint8_t* srcRow = bgraData + srcY * width * 4;
            int rowOff = y * inS;
            for (int x = 0; x < inS; ++x) {
                const uint8_t* px = srcRow + xLut[x];
                planeR[rowOff + x] = px[2] * inv255;
                planeG[rowOff + x] = px[1] * inv255;
                planeB[rowOff + x] = px[0] * inv255;
            }
        }
    }

    cudaMemcpyAsync(d_input_, h_input_, inputBytes_,
                     cudaMemcpyHostToDevice, stream_);

    if (!context_->enqueueV3(stream_))
        return false;

    cudaMemcpyAsync(h_output_, d_output_, outputBytes_,
                     cudaMemcpyDeviceToHost, stream_);
    cudaStreamSynchronize(stream_);

    // ── Post-process ──────────────────────────────────────────────────
    float* outputData = static_cast<float*>(h_output_);

    // Find output tensor dynamically
    int numIO = engine_->getNbIOTensors();
    const char* outputName = nullptr;
    for (int i = 0; i < numIO; ++i) {
        auto name = engine_->getIOTensorName(i);
        if (engine_->getTensorIOMode(name) == nvinfer1::TensorIOMode::kOUTPUT) {
            outputName = name;
            break;
        }
    }
    auto outputDims = context_->getTensorShape(outputName);

    int dim1 = outputDims.nbDims >= 2 ? outputDims.d[1] : 0;
    int dim2 = outputDims.nbDims >= 3 ? outputDims.d[2] : 0;

    out.clear();
    out.reserve(64);

    // Minimum box size filter (reduces false positives)
    float minBoxSize = static_cast<float>(width) * 0.01f;  // 1% of capture

    if (dim1 > dim2) {
        // YOLOv5-style: [1, N, 5+C]
        int numDets   = dim1;
        int rowLen    = dim2;
        int numClasses = rowLen - 5;

        for (int i = 0; i < numDets; ++i) {
            const float* row = outputData + i * rowLen;
            float objConf = row[4];
            if (objConf < confThresh) continue;

            int bestClass = 0;
            float bestScore = 0.f;
            for (int c = 0; c < numClasses; ++c) {
                float s = row[5 + c] * objConf;
                if (s > bestScore) { bestScore = s; bestClass = c; }
            }
            if (bestScore < confThresh) continue;

            Detection d;
            d.x = row[0] * (static_cast<float>(width)  / inS);
            d.y = row[1] * (static_cast<float>(height) / inS);
            d.w = row[2] * (static_cast<float>(width)  / inS);
            d.h = row[3] * (static_cast<float>(height) / inS);
            d.confidence = bestScore;
            d.classId    = bestClass;

            // Filter tiny/degenerate boxes (false positives)
            if (d.w < minBoxSize || d.h < minBoxSize) continue;
            // Filter unreasonable aspect ratios
            float aspect = d.w / (d.h + 1e-6f);
            if (aspect > 5.f || aspect < 0.1f) continue;

            out.push_back(d);
        }
    } else {
        // YOLOv8-style: [1, 4+C, N]
        int numClasses = dim1 - 4;
        int numDets    = dim2;

        for (int i = 0; i < numDets; ++i) {
            int bestClass = 0;
            float bestScore = 0.f;
            for (int c = 0; c < numClasses; ++c) {
                float s = outputData[(4 + c) * numDets + i];
                if (s > bestScore) { bestScore = s; bestClass = c; }
            }
            if (bestScore < confThresh) continue;

            Detection d;
            d.x = outputData[0 * numDets + i] * (static_cast<float>(width)  / inS);
            d.y = outputData[1 * numDets + i] * (static_cast<float>(height) / inS);
            d.w = outputData[2 * numDets + i] * (static_cast<float>(width)  / inS);
            d.h = outputData[3 * numDets + i] * (static_cast<float>(height) / inS);
            d.confidence = bestScore;
            d.classId    = bestClass;

            if (d.w < minBoxSize || d.h < minBoxSize) continue;
            float aspect = d.w / (d.h + 1e-6f);
            if (aspect > 5.f || aspect < 0.1f) continue;

            out.push_back(d);
        }
    }

    nms(out, nmsThresh);

    auto t1 = std::chrono::high_resolution_clock::now();
    lastInferMs_ = std::chrono::duration<float, std::milli>(t1 - t0).count();
    return true;
}

void InferenceEngine::postProcess(const float* /*rawOutput*/, int /*numDetections*/,
                                   float /*confThresh*/, float /*nmsThresh*/,
                                   std::vector<Detection>& /*out*/) {
    // Handled inline in infer()
}

void InferenceEngine::nms(std::vector<Detection>& dets, float nmsThresh) {
    std::sort(dets.begin(), dets.end(),
              [](const Detection& a, const Detection& b) {
                  return a.confidence > b.confidence;
              });

    std::vector<bool> suppressed(dets.size(), false);
    for (size_t i = 0; i < dets.size(); ++i) {
        if (suppressed[i]) continue;
        for (size_t j = i + 1; j < dets.size(); ++j) {
            if (suppressed[j]) continue;
            if (iou(dets[i], dets[j]) > nmsThresh)
                suppressed[j] = true;
        }
    }

    std::vector<Detection> filtered;
    filtered.reserve(dets.size());
    for (size_t i = 0; i < dets.size(); ++i)
        if (!suppressed[i])
            filtered.push_back(dets[i]);
    dets = std::move(filtered);
}
