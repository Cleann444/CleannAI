#pragma once
// ────────────────────────────────────────────────────────────────────────────
// ui.h – Dear ImGui control panel
// ────────────────────────────────────────────────────────────────────────────
#include "aimbot.h"
#include "render.h"
#include "input.h"

#include <nlohmann/json.hpp>
#include <filesystem>
#include <string>
#include <vector>

struct AppConfig {
    // Aim
    AimSettings     aim;
    ActivationKey   activationKey = ActivationKey::RightClick;

    // Inference
    std::string     modelPath;
    std::string     precision  = "FP16";
    int             inputSize  = 640;       // Model input (640 for your TRT engine)
    int             captureSize = 320;      // Capture region (smaller = less GPU lag)
    int             inferCapFps = 60;       // Max inference FPS
    float           confThresh = 0.45f;
    float           nmsThresh  = 0.50f;
    int             gpuDevice  = 0;

    // FPS caps for all rendering pipelines
    int             overlayCapFps = 30;     // Overlay ESP drawing FPS cap
    int             menuCapFps    = 20;     // Menu UI drawing FPS cap
    int             loopCapFps    = 120;    // Main loop FPS cap

    // Render
    RenderSettings  render;

    // Serialisation
    void save(const std::filesystem::path& path) const;
    void load(const std::filesystem::path& path);
};

class UIPanel {
public:
    UIPanel();

    // Draw the control panel.  Returns true if model needs reloading.
    bool draw(AppConfig& cfg,
              float renderFps, float inferenceFps,
              const std::vector<std::string>& gpuList,
              bool modelLoaded);

    bool wantsModelReload() const { return modelReload_; }
    void clearModelReload()       { modelReload_ = false; }

private:
    bool modelReload_ = false;
    char modelPathBuf_[512] = {};
    int  boneIdx_     = 0;
    int  actKeyIdx_   = 0;
    int  precIdx_     = 1;   // FP16
    int  inputSizeIdx_= 1;  // 640
    int  gpuIdx_      = 0;
};
