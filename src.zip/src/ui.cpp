// ────────────────────────────────────────────────────────────────────────────
// ui.cpp – Dear ImGui control panel + JSON config save/load
// ────────────────────────────────────────────────────────────────────────────
#include "ui.h"
#include <imgui.h>
#include <fstream>
#include <algorithm>

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <commdlg.h>
#pragma comment(lib, "comdlg32.lib")

using json = nlohmann::json;

// ── AppConfig serialisation ───────────────────────────────────────────────

void AppConfig::save(const std::filesystem::path& path) const {
    json j;

    // Aim
    j["aim"]["enabled"]              = aim.enabled;
    j["aim"]["fov_radius"]           = aim.fovRadius;
    j["aim"]["sticky_aim"]           = aim.stickyAim;
    j["aim"]["anti_overshoot"]       = aim.antiOvershoot;
    j["aim"]["ai_speed"]             = aim.aiSpeed;
    j["aim"]["smooth_factor"]        = aim.smoothFactor;
    j["aim"]["sensitivity"]          = aim.sensitivity;
    j["aim"]["prediction_enabled"]   = aim.predictionEnabled;
    j["aim"]["prediction_strength"]  = aim.predictionStrength;
    j["aim"]["target_bone"]          = boneName(aim.bone);
    j["aim"]["activation_key"]       = activationKeyName(activationKey);

    // Inference
    j["inference"]["model_path"]            = modelPath;
    j["inference"]["precision"]             = precision;
    j["inference"]["input_size"]            = inputSize;
    j["inference"]["confidence_threshold"]  = confThresh;
    j["inference"]["nms_threshold"]         = nmsThresh;
    j["inference"]["gpu_device"]            = gpuDevice;

    // FPS caps
    j["fps"]["inference_cap"]   = inferCapFps;
    j["fps"]["overlay_cap"]     = overlayCapFps;
    j["fps"]["menu_cap"]        = menuCapFps;
    j["fps"]["loop_cap"]        = loopCapFps;

    // Render
    j["render"]["show_fov"]            = render.showFov;
    j["render"]["rainbow_fov"]         = render.rainbowFov;
    j["render"]["show_boxes"]          = render.showBoxes;
    j["render"]["show_skeleton"]       = render.showSkeleton;
    j["render"]["show_confidence"]     = render.showConfidence;
    j["render"]["box_smoothing_alpha"] = render.boxSmoothAlpha;
    j["render"]["glow_intensity"]      = render.glowIntensity;
    j["render"]["glow_passes"]         = render.glowPasses;
    j["render"]["skeleton_thickness"]  = render.skeletonThick;
    j["render"]["box_color"]           = render.boxColor;
    j["render"]["target_color"]        = render.targetColor;
    j["render"]["skeleton_color"]      = render.skeletonColor;

    std::ofstream f(path);
    f << j.dump(2);
}

void AppConfig::load(const std::filesystem::path& path) {
    std::ifstream f(path);
    if (!f) return;

    json j;
    f >> j;

    // Aim
    if (j.contains("aim")) {
        auto& a = j["aim"];
        aim.enabled             = a.value("enabled", true);
        aim.fovRadius           = a.value("fov_radius", 200.f);
        aim.stickyAim           = a.value("sticky_aim", false);
        aim.antiOvershoot       = a.value("anti_overshoot", true);
        aim.aiSpeed             = a.value("ai_speed", 5.f);
        aim.smoothFactor        = a.value("smooth_factor", 0.35f);
        aim.sensitivity         = a.value("sensitivity", 1.0f);
        aim.predictionEnabled   = a.value("prediction_enabled", true);
        aim.predictionStrength  = a.value("prediction_strength", 0.5f);

        std::string bonStr = a.value("target_bone", "Head");
        if (bonStr == "Neck")       aim.bone = TargetBone::Neck;
        else if (bonStr == "Chest") aim.bone = TargetBone::Chest;
        else                        aim.bone = TargetBone::Head;

        std::string actStr = a.value("activation_key", "Right Click");
        activationKey = activationKeyFromName(actStr);
    }

    // Inference
    if (j.contains("inference")) {
        auto& inf = j["inference"];
        modelPath  = inf.value("model_path", "");
        precision  = inf.value("precision", "FP16");
        inputSize  = inf.value("input_size", 640);
        confThresh = inf.value("confidence_threshold", 0.45f);
        nmsThresh  = inf.value("nms_threshold", 0.50f);
        gpuDevice  = inf.value("gpu_device", 0);
    }

    // FPS caps
    if (j.contains("fps")) {
        auto& fps = j["fps"];
        inferCapFps   = fps.value("inference_cap", 60);
        overlayCapFps = fps.value("overlay_cap", 30);
        menuCapFps    = fps.value("menu_cap", 20);
        loopCapFps    = fps.value("loop_cap", 120);
    }

    // Render
    if (j.contains("render")) {
        auto& r = j["render"];
        render.showFov         = r.value("show_fov", true);
        render.rainbowFov      = r.value("rainbow_fov", false);
        render.showBoxes       = r.value("show_boxes", true);
        render.showSkeleton    = r.value("show_skeleton", true);
        render.showConfidence  = r.value("show_confidence", true);
        render.boxSmoothAlpha  = r.value("box_smoothing_alpha", 0.35f);
        render.glowIntensity   = r.value("glow_intensity", 0.40f);
        render.glowPasses      = r.value("glow_passes", 2);
        render.skeletonThick   = r.value("skeleton_thickness", 2.0f);

        if (r.contains("box_color"))
            render.boxColor = r["box_color"].get<std::array<float,4>>();
        if (r.contains("target_color"))
            render.targetColor = r["target_color"].get<std::array<float,4>>();
        if (r.contains("skeleton_color"))
            render.skeletonColor = r["skeleton_color"].get<std::array<float,4>>();
    }
}

// ── UIPanel ───────────────────────────────────────────────────────────────

UIPanel::UIPanel() {
    memset(modelPathBuf_, 0, sizeof(modelPathBuf_));
}

bool UIPanel::draw(AppConfig& cfg,
                    float renderFps, float inferenceFps,
                    const std::vector<std::string>& gpuList,
                    bool modelLoaded) {
    modelReload_ = false;

    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->WorkPos);
    ImGui::SetNextWindowSize(vp->WorkSize);
    ImGui::Begin("Cleann", nullptr,
                  ImGuiWindowFlags_NoCollapse |
                  ImGuiWindowFlags_NoMove |
                  ImGuiWindowFlags_NoResize |
                  ImGuiWindowFlags_NoTitleBar);

    // ── Status bar ────────────────────────────────────────────────────
    ImVec4 statusColor = cfg.aim.enabled
        ? ImVec4(0.1f, 1.f, 0.4f, 1.f)
        : ImVec4(1.f, 0.3f, 0.3f, 1.f);
    ImGui::TextColored(statusColor, cfg.aim.enabled ? "AIM: ON" : "AIM: OFF");
    ImGui::SameLine(200);
    ImGui::Text("F1 to toggle");

    ImGui::Separator();

    // ── FPS counters ──────────────────────────────────────────────────
    ImGui::Text("Render:    %.1f FPS", renderFps);
    ImGui::SameLine(220);
    ImGui::Text("Inference: %.1f FPS", inferenceFps);

    ImGui::Separator();

    // ── Model section ─────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("Model", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::InputText("Model Path", modelPathBuf_, sizeof(modelPathBuf_));

        if (ImGui::Button("Load Model")) {
            cfg.modelPath = modelPathBuf_;
            modelReload_  = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Browse...")) {
            // Open Windows file dialog
            char filePath[512] = {};
            OPENFILENAMEA ofn = {};
            ofn.lStructSize = sizeof(ofn);
            ofn.lpstrFilter = "Model Files\0*.onnx;*.trt;*.engine\0All Files\0*.*\0";
            ofn.lpstrFile = filePath;
            ofn.nMaxFile = sizeof(filePath);
            ofn.Flags = OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
            if (GetOpenFileNameA(&ofn)) {
                strncpy_s(modelPathBuf_, filePath, sizeof(modelPathBuf_) - 1);
                cfg.modelPath = modelPathBuf_;
                modelReload_ = true;
            }
        }
        ImGui::SameLine();
        if (modelLoaded) {
            ImGui::TextColored(ImVec4(0.1f, 1.f, 0.4f, 1.f), "Ready");
        } else if (inferenceFps <= 0.f && !cfg.modelPath.empty()) {
            ImGui::TextColored(ImVec4(1.f, 0.8f, 0.2f, 1.f), "Loading...");
        } else {
            ImGui::TextColored(ImVec4(1.f, 0.3f, 0.3f, 1.f), "Not Loaded");
        }

        const char* precisions[] = {"FP32", "FP16", "INT8"};
        if (cfg.precision == "FP32") precIdx_ = 0;
        else if (cfg.precision == "FP16") precIdx_ = 1;
        else precIdx_ = 2;

        if (ImGui::Combo("Precision", &precIdx_, precisions, 3))
            cfg.precision = precisions[precIdx_];

        const char* inputSizes[] = {"320x320", "640x640"};
        inputSizeIdx_ = (cfg.inputSize == 320) ? 0 : 1;
        if (ImGui::Combo("Model Input", &inputSizeIdx_, inputSizes, 2)) {
            cfg.inputSize = (inputSizeIdx_ == 0) ? 320 : 640;
            modelReload_ = true;
        }

        // Capture size — smaller = faster + less GPU lag
        const char* capSizes[] = {"320x320 (Fast)", "480x480 (Balanced)", "640x640 (Quality)"};
        int capIdx = (cfg.captureSize <= 320) ? 0 : (cfg.captureSize <= 480) ? 1 : 2;
        if (ImGui::Combo("Capture Size", &capIdx, capSizes, 3)) {
            cfg.captureSize = (capIdx == 0) ? 320 : (capIdx == 1) ? 480 : 640;
        }

        if (!gpuList.empty()) {
            gpuIdx_ = std::clamp(cfg.gpuDevice, 0, static_cast<int>(gpuList.size()) - 1);
            std::vector<const char*> gpuNames;
            for (const auto& name : gpuList)
                gpuNames.push_back(name.c_str());

            if (ImGui::Combo("GPU Device", &gpuIdx_, gpuNames.data(),
                              static_cast<int>(gpuNames.size()))) {
                cfg.gpuDevice = gpuIdx_;
                modelReload_ = true;
            }
        }

        ImGui::SliderFloat("Confidence", &cfg.confThresh, 0.1f, 1.0f, "%.2f");
        ImGui::SliderFloat("NMS Threshold", &cfg.nmsThresh, 0.1f, 1.0f, "%.2f");
    }

    ImGui::Separator();

    // ── FPS Caps section ──────────────────────────────────────────────
    if (ImGui::CollapsingHeader("FPS Caps", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::SliderInt("Inference FPS", &cfg.inferCapFps, 10, 240);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Max inference cycles per second.\nHigher = faster detection, more GPU usage.");

        ImGui::SliderInt("Overlay FPS", &cfg.overlayCapFps, 5, 144);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("ESP overlay draw rate.\nLower = less GPU usage, slightly less smooth visuals.");

        ImGui::SliderInt("Menu FPS", &cfg.menuCapFps, 5, 60);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Settings window draw rate.\nKeep low — the menu doesn't need speed.");

        ImGui::SliderInt("Main Loop FPS", &cfg.loopCapFps, 30, 500);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Master loop tick rate. Controls aim input polling speed.\nHigher = more responsive aim, more CPU usage.");
    }

    ImGui::Separator();

    // ── Aim section ───────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("Aim Settings", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::SliderFloat("FOV Radius", &cfg.aim.fovRadius, 50.f, 500.f, "%.0f px");

        ImGui::SliderFloat("AI Speed", &cfg.aim.aiSpeed, 1.f, 20.f, "%.1f");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(60);
        ImGui::InputFloat("##speed_edit", &cfg.aim.aiSpeed, 0, 0, "%.1f");
        cfg.aim.aiSpeed = std::clamp(cfg.aim.aiSpeed, 1.f, 20.f);

        ImGui::SliderFloat("Smooth Factor", &cfg.aim.smoothFactor,
                            0.05f, 1.0f, "%.2f");

        // ── Sensitivity slider ──────────────────────────────────
        ImGui::SliderFloat("Sensitivity", &cfg.aim.sensitivity,
                            0.1f, 3.0f, "%.2f");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Mouse movement multiplier. Lower = more precise.");

        ImGui::Separator();

        // ── Prediction controls ─────────────────────────────────
        ImGui::Checkbox("Prediction", &cfg.aim.predictionEnabled);
        if (cfg.aim.predictionEnabled) {
            ImGui::SameLine(220);
            ImGui::SetNextItemWidth(150);
            ImGui::SliderFloat("Strength##pred", &cfg.aim.predictionStrength,
                                0.0f, 1.0f, "%.2f");
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("How far ahead to predict target movement.\n0 = no prediction, 1 = full frame extrapolation.");
        }

        ImGui::Separator();

        const char* bones[] = {"Head", "Neck", "Chest"};
        boneIdx_ = static_cast<int>(cfg.aim.bone);
        if (ImGui::Combo("Target Bone", &boneIdx_, bones, 3))
            cfg.aim.bone = static_cast<TargetBone>(boneIdx_);

        const char* actKeys[] = {
            "Right Click", "Mouse4", "Mouse5", "Middle Click",
            "Alt", "Ctrl", "Shift"
        };
        actKeyIdx_ = static_cast<int>(cfg.activationKey);
        if (ImGui::Combo("Activation Key", &actKeyIdx_, actKeys, 7))
            cfg.activationKey = static_cast<ActivationKey>(actKeyIdx_);

        ImGui::Checkbox("Sticky Aim", &cfg.aim.stickyAim);
        ImGui::SameLine(220);
        ImGui::Checkbox("Anti-Overshoot", &cfg.aim.antiOvershoot);
    }

    ImGui::Separator();

    // ── Visual section ────────────────────────────────────────────────
    if (ImGui::CollapsingHeader("Visual Settings", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::Checkbox("Show FOV Circle", &cfg.render.showFov);
        ImGui::SameLine(220);
        ImGui::Checkbox("Rainbow FOV", &cfg.render.rainbowFov);

        ImGui::Checkbox("Show Bounding Boxes", &cfg.render.showBoxes);
        ImGui::SameLine(220);
        ImGui::Checkbox("Show Confidence", &cfg.render.showConfidence);

        ImGui::Checkbox("Show Skeleton ESP", &cfg.render.showSkeleton);

        ImGui::Separator();
        ImGui::Text("Performance");
        ImGui::SliderFloat("Box Smoothing", &cfg.render.boxSmoothAlpha,
                            0.10f, 1.0f, "%.2f");
        ImGui::SliderFloat("Glow Intensity", &cfg.render.glowIntensity,
                            0.0f, 1.0f, "%.2f");
        ImGui::SliderInt("Glow Passes", &cfg.render.glowPasses, 0, 4);

        ImGui::Separator();
        ImGui::Text("Skeleton");
        ImGui::SliderFloat("Skeleton Thickness", &cfg.render.skeletonThick,
                            1.0f, 5.0f, "%.1f");
        ImGui::ColorEdit4("Skeleton Color", cfg.render.skeletonColor.data(),
                           ImGuiColorEditFlags_AlphaBar);

        ImGui::Separator();
        ImGui::Text("Colors");
        ImGui::ColorEdit4("Box Color", cfg.render.boxColor.data(),
                           ImGuiColorEditFlags_AlphaBar);
        ImGui::ColorEdit4("Target Color", cfg.render.targetColor.data(),
                           ImGuiColorEditFlags_AlphaBar);
    }

    ImGui::Separator();

    // ── Config save/load ──────────────────────────────────────────────
    if (ImGui::Button("Save Config")) {
        cfg.save("config/user_config.json");
    }
    ImGui::SameLine();
    if (ImGui::Button("Load Config")) {
        cfg.load("config/user_config.json");
        strncpy_s(modelPathBuf_, cfg.modelPath.c_str(), sizeof(modelPathBuf_) - 1);
    }

    ImGui::End();
    return modelReload_;
}
