// ────────────────────────────────────────────────────────────────────────────
// input.cpp – SendInput mouse movement + hotkey polling
// ────────────────────────────────────────────────────────────────────────────
#include "input.h"

void InputManager::moveMouse(int dx, int dy) {
    if (dx == 0 && dy == 0) return;

    INPUT input = {};
    input.type       = INPUT_MOUSE;
    input.mi.dx      = dx;
    input.mi.dy      = dy;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;

    SendInput(1, &input, sizeof(INPUT));
}

bool InputManager::isActivationHeld(ActivationKey key) {
    switch (key) {
        case ActivationKey::RightClick:
            return (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
        case ActivationKey::Mouse4:
            return (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;
        case ActivationKey::Mouse5:
            return (GetAsyncKeyState(VK_XBUTTON2) & 0x8000) != 0;
        case ActivationKey::MiddleClick:
            return (GetAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
        case ActivationKey::Alt:
            return (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
        case ActivationKey::Ctrl:
            return (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
        case ActivationKey::Shift:
            return (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    }
    return false;
}

bool InputManager::wasTogglePressed() {
    // Check F1 key-down transition
    static bool prevState = false;
    bool current = (GetAsyncKeyState(VK_F1) & 0x8000) != 0;
    bool pressed = current && !prevState;
    prevState = current;
    return pressed;
}
