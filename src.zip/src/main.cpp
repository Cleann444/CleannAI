// ────────────────────────────────────────────────────────────────────────────
// main.cpp – Performance-optimized: minimal GPU footprint
//   - Capture synced to inference rate (no wasted grabs)
//   - Overlay on its own D3D device (doesn't block game GPU queue)
//   - Overlay at 30fps (matches inference update rate)
//   - DPI manifest + runtime fallback
// ────────────────────────────────────────────────────────────────────────────
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <dwmapi.h>

#include <d3d11.h>
#include <dxgi.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <imgui_internal.h>

#include "capture.h"
#include "inference.h"
#include "aimbot.h"
#include "input.h"
#include "render.h"
#include "ui.h"

#include <atomic>
#include <thread>
#include <chrono>
#include <mutex>
#include <filesystem>
#include <algorithm>
#include <shellscalingapi.h>
#pragma comment(lib, "Shcore.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ── Globals ───────────────────────────────────────────────────────────────
static std::atomic<bool> g_running{true};
static std::mutex g_detMutex;
static std::vector<Detection> g_detections;
static float g_inferFps = 0.f;
static std::atomic<bool> g_modelReady{false};   // shared engine status
static std::atomic<int>  g_modelStatus{0};      // 0=none, 1=loading, 2=ready, 3=failed

// ── D3D helper ────────────────────────────────────────────────────────────
struct D3DState {
    ID3D11Device*           device    = nullptr;
    ID3D11DeviceContext*    devCtx    = nullptr;
    IDXGISwapChain*         swapChain = nullptr;
    ID3D11RenderTargetView* rtv       = nullptr;

    void releaseAll() {
        if (rtv)       { rtv->Release();       rtv = nullptr; }
        if (swapChain) { swapChain->Release();  swapChain = nullptr; }
        if (devCtx)    { devCtx->Release();     devCtx = nullptr; }
        if (device)    { device->Release();     device = nullptr; }
    }

    void resize(int w, int h) {
        if (!swapChain || w <= 0 || h <= 0) return;
        if (rtv) { rtv->Release(); rtv = nullptr; }
        swapChain->ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, 0);
        ID3D11Texture2D* bb = nullptr;
        swapChain->GetBuffer(0, IID_PPV_ARGS(&bb));
        device->CreateRenderTargetView(bb, nullptr, &rtv);
        bb->Release();
    }
};

static D3DState* g_menuD3D = nullptr;

// ── Window procedures ─────────────────────────────────────────────────────
LRESULT CALLBACK MenuWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;
    switch (msg) {
        case WM_DESTROY:
            g_running = false;
            PostQuitMessage(0);
            return 0;
        case WM_SIZE:
            if (g_menuD3D && wParam != SIZE_MINIMIZED) {
                g_menuD3D->resize(LOWORD(lParam), HIWORD(lParam));
            }
            return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

LRESULT CALLBACK OverlayWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_DESTROY: return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

static bool createD3D(HWND hwnd, int w, int h, D3DState& s) {
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount        = 2;
    sd.BufferDesc.Width   = w;
    sd.BufferDesc.Height  = h;
    sd.BufferDesc.Format  = DXGI_FORMAT_B8G8R8A8_UNORM;
    sd.BufferUsage        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow       = hwnd;
    sd.SampleDesc.Count   = 1;
    sd.Windowed           = TRUE;
    sd.SwapEffect         = DXGI_SWAP_EFFECT_DISCARD;
    sd.Flags              = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

    D3D_FEATURE_LEVEL fl = D3D_FEATURE_LEVEL_11_0;
    if (FAILED(D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
            &fl, 1, D3D11_SDK_VERSION,
            &sd, &s.swapChain, &s.device, nullptr, &s.devCtx)))
        return false;

    ID3D11Texture2D* bb = nullptr;
    s.swapChain->GetBuffer(0, IID_PPV_ARGS(&bb));
    s.device->CreateRenderTargetView(bb, nullptr, &s.rtv);
    bb->Release();
    return true;
}

// ── Combined capture+inference thread ─────────────────────────────────────
// Merging these eliminates wasted captures — we only grab a frame when
// we're ready to immediately run inference on it.
static void captureInferenceThread(AppConfig& cfg,
                                     std::atomic<bool>& reloadFlag) {
    // Run at lowest priority so we don't steal from the game
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_IDLE);

    ScreenCapture capture;
    InferenceEngine engine;

    capture.init(cfg.gpuDevice);
    int lastGpu = cfg.gpuDevice;

    while (g_running) {
        // Handle model reload
        if (reloadFlag.load()) {
            reloadFlag = false;
            int newGpu = cfg.gpuDevice;
            if (newGpu != lastGpu) {
                capture.shutdown();
                capture.init(newGpu);
                lastGpu = newGpu;
            }
            engine.selectGPU(newGpu);
            if (!cfg.modelPath.empty()) {
                g_modelStatus.store(1);  // loading
                g_modelReady.store(false);
                bool ok = engine.loadModel(cfg.modelPath, cfg.inputSize, cfg.precision);
                if (ok) {
                    g_modelStatus.store(2);  // ready
                    g_modelReady.store(true);
                } else {
                    g_modelStatus.store(3);  // failed
                    g_modelReady.store(false);
                }
            }
        }

        if (!engine.isReady()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }

        int captureSize = cfg.captureSize;  // Use smaller capture (320) for less GPU lag
        if (!capture.captureRegion(captureSize)) {
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
            continue;
        }

        auto& buf = capture.tripleBuffer();
        auto& frame = buf.readBuffer();
        if (frame.pixels.empty()) continue;

        std::vector<Detection> dets;
        engine.infer(frame.pixels.data(), frame.width, frame.height,
                      cfg.confThresh, cfg.nmsThresh, dets);
        {
            std::lock_guard lock(g_detMutex);
            g_detections = std::move(dets);
        }
        float ms = engine.lastMs();
        g_inferFps = (ms > 0.f) ? 1000.f / ms : 0.f;

        // Dynamic FPS cap based on user setting
        int capFps = (std::max)(10, (std::min)(cfg.inferCapFps, 120));
        int sleepMs = (std::max)(1, static_cast<int>(1000.f / capFps - ms));
        std::this_thread::sleep_for(std::chrono::milliseconds(sleepMs));
    }

    capture.shutdown();
}

// ── Apply ImGui dark theme ────────────────────────────────────────────────
static void applyDarkTheme() {
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding    = 8.f;
    style.FrameRounding     = 4.f;
    style.GrabRounding      = 4.f;
    style.ScrollbarRounding = 6.f;
    style.WindowPadding     = ImVec2(12, 12);
    style.FramePadding      = ImVec2(8, 4);
    style.ItemSpacing       = ImVec2(8, 6);

    ImVec4* c = style.Colors;
    c[ImGuiCol_WindowBg]         = ImVec4(0.051f, 0.051f, 0.051f, 0.95f);
    c[ImGuiCol_FrameBg]          = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    c[ImGuiCol_FrameBgHovered]   = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    c[ImGuiCol_FrameBgActive]    = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
    c[ImGuiCol_TitleBg]          = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
    c[ImGuiCol_TitleBgActive]    = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
    c[ImGuiCol_CheckMark]        = ImVec4(0.10f, 1.00f, 0.40f, 1.00f);
    c[ImGuiCol_SliderGrab]       = ImVec4(0.10f, 0.80f, 0.40f, 1.00f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(0.15f, 1.00f, 0.50f, 1.00f);
    c[ImGuiCol_Button]           = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    c[ImGuiCol_ButtonHovered]    = ImVec4(0.15f, 0.60f, 0.30f, 1.00f);
    c[ImGuiCol_ButtonActive]     = ImVec4(0.10f, 0.80f, 0.35f, 1.00f);
    c[ImGuiCol_Header]           = ImVec4(0.10f, 0.40f, 0.25f, 0.80f);
    c[ImGuiCol_HeaderHovered]    = ImVec4(0.12f, 0.55f, 0.30f, 0.80f);
    c[ImGuiCol_HeaderActive]     = ImVec4(0.15f, 0.65f, 0.35f, 0.80f);
    c[ImGuiCol_Separator]        = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
    c[ImGuiCol_Text]             = ImVec4(0.90f, 0.93f, 0.90f, 1.00f);
}

// ── Main ──────────────────────────────────────────────────────────────────
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    // ── DPI: per-monitor V2 via runtime + manifest ──────────────────
    HMODULE user32 = GetModuleHandleA("user32.dll");
    if (user32) {
        typedef BOOL(WINAPI* SDPAC)(DPI_AWARENESS_CONTEXT);
        auto fn = (SDPAC)GetProcAddress(user32, "SetProcessDpiAwarenessContext");
        if (fn) fn(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        else SetProcessDPIAware();
    } else {
        SetProcessDPIAware();
    }

    // ── Get physical screen resolution ──────────────────────────────
    DEVMODEW dm = {};
    dm.dmSize = sizeof(dm);
    EnumDisplaySettingsW(nullptr, ENUM_CURRENT_SETTINGS, &dm);
    int screenW = static_cast<int>(dm.dmPelsWidth);
    int screenH = static_cast<int>(dm.dmPelsHeight);
    if (screenW <= 0) screenW = GetSystemMetrics(SM_CXSCREEN);
    if (screenH <= 0) screenH = GetSystemMetrics(SM_CYSCREEN);

    // ════════════════════════════════════════════════════════════════
    //  WINDOW 1: Menu
    // ════════════════════════════════════════════════════════════════
    {
        WNDCLASSEX wc = {};
        wc.cbSize = sizeof(wc);
        wc.style  = CS_HREDRAW | CS_VREDRAW;
        wc.lpfnWndProc  = MenuWndProc;
        wc.hInstance     = hInstance;
        wc.lpszClassName = TEXT("CleannMenu");
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        RegisterClassEx(&wc);
    }
    int menuW = 450, menuH = 820;
    HWND menuHwnd = CreateWindowEx(
        WS_EX_TOPMOST, TEXT("CleannMenu"), TEXT("Cleann"),
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        50, 50, menuW, menuH,
        nullptr, nullptr, hInstance, nullptr);
    if (!menuHwnd) return 1;

    // Get ACTUAL client area (excludes title bar, borders)
    RECT clientRect;
    GetClientRect(menuHwnd, &clientRect);
    int menuClientW = clientRect.right - clientRect.left;
    int menuClientH = clientRect.bottom - clientRect.top;

    // ════════════════════════════════════════════════════════════════
    //  WINDOW 2: Overlay
    // ════════════════════════════════════════════════════════════════
    {
        WNDCLASSEX wc = {};
        wc.cbSize = sizeof(wc);
        wc.style  = CS_HREDRAW | CS_VREDRAW;
        wc.lpfnWndProc  = OverlayWndProc;
        wc.hInstance     = hInstance;
        wc.lpszClassName = TEXT("CleannOverlay");
        RegisterClassEx(&wc);
    }
    HWND overlayHwnd = CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE,
        TEXT("CleannOverlay"), TEXT(""),
        WS_POPUP, 0, 0, screenW, screenH,
        nullptr, nullptr, hInstance, nullptr);
    if (!overlayHwnd) return 1;
    SetLayeredWindowAttributes(overlayHwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
    MARGINS margins = {-1};
    DwmExtendFrameIntoClientArea(overlayHwnd, &margins);
    ShowWindow(overlayHwnd, SW_SHOWNOACTIVATE);

    // ── D3D11: SEPARATE devices (overlay doesn't block game GPU) ────
    D3DState menuD3D, overlayD3D;
    if (!createD3D(menuHwnd, menuClientW, menuClientH, menuD3D)) return 1;
    if (!createD3D(overlayHwnd, screenW, screenH, overlayD3D)) return 1;
    g_menuD3D = &menuD3D;  // enable WM_SIZE resize handling

    // ── ImGui context 1: MENU ────────────────────────────────────────
    ImGuiContext* menuCtx = ImGui::CreateContext();
    ImGui::SetCurrentContext(menuCtx);
    applyDarkTheme();
    ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui_ImplWin32_Init(menuHwnd);
    ImGui_ImplDX11_Init(menuD3D.device, menuD3D.devCtx);

    // ── ImGui context 2: OVERLAY ─────────────────────────────────────
    ImGuiContext* overlayCtx = ImGui::CreateContext();
    ImGui::SetCurrentContext(overlayCtx);
    ImGui_ImplWin32_Init(overlayHwnd);
    ImGui_ImplDX11_Init(overlayD3D.device, overlayD3D.devCtx);

    // ── Load config ──────────────────────────────────────────────────
    AppConfig cfg;
    if (std::filesystem::exists("config/user_config.json"))
        cfg.load("config/user_config.json");
    else if (std::filesystem::exists("config/default_config.json"))
        cfg.load("config/default_config.json");

    auto gpuList = InferenceEngine::enumerateGPUs();

    // ── Subsystems ───────────────────────────────────────────────────
    Aimbot aimbot;
    OverlayRenderer renderer;
    UIPanel uiPanel;

    std::atomic<bool> reloadFlag{false};
    if (!cfg.modelPath.empty()) reloadFlag = true;

    // Single combined capture+inference thread (no wasted GPU grabs)
    std::thread ciThread(captureInferenceThread,
                          std::ref(cfg), std::ref(reloadFlag));

    // ── Timing ───────────────────────────────────────────────────────
    float renderFps = 0.f;
    auto lastFrame = std::chrono::high_resolution_clock::now();
    int  frameCount = 0;
    float fpsAccum = 0.f;

    int menuCounter = 0;
    int overlayCounter = 0;

    MSG msg = {};
    while (g_running) {
        auto loopStart = std::chrono::high_resolution_clock::now();

        while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            if (msg.message == WM_QUIT) g_running = false;
        }
        if (!g_running) break;

        if (InputManager::wasTogglePressed())
            cfg.aim.enabled = !cfg.aim.enabled;

        auto now = std::chrono::high_resolution_clock::now();
        float dt = std::chrono::duration<float>(now - lastFrame).count();
        lastFrame = now;
        dt = (std::min)(dt, 0.05f);

        // ── Get detections ───────────────────────────────────────────
        std::vector<Detection> dets;
        { std::lock_guard lock(g_detMutex); dets = g_detections; }

        float screenCx = screenW / 2.f;
        float screenCy = screenH / 2.f;
        float capX = (screenW - cfg.captureSize) / 2.f;
        float capY = (screenH - cfg.captureSize) / 2.f;

        // ── Tracking + Aim ───────────────────────────────────────────
        aimbot.updateTracking(dets, capX, capY, cfg.aim.bone);

        bool activated = InputManager::isActivationHeld(cfg.activationKey);
        AimResult aimResult;
        if (cfg.aim.enabled && activated) {
            aimResult = aimbot.computeAim(screenCx, screenCy, cfg.aim);
            if (aimResult.shouldAim) {
                InputManager::moveMouse(static_cast<int>(aimResult.deltaX),
                                         static_cast<int>(aimResult.deltaY));
            }
        }

        // ── Update ESP data every frame (cheap) ──────────────────────
        renderer.updateBoxes(aimbot.trackedTargets(), capX, capY,
                              cfg.render.boxSmoothAlpha);
        renderer.interpolateBoxes(dt);

        int activeTargetId = -1;
        if (aimResult.targetIdx >= 0 &&
            aimResult.targetIdx < static_cast<int>(aimbot.trackedTargets().size()))
            activeTargetId = aimbot.trackedTargets()[aimResult.targetIdx].id;

        // ════════════════════════════════════════════════════════════
        //  OVERLAY: dynamic FPS cap from config
        // ════════════════════════════════════════════════════════════
        int overlaySkip = (std::max)(1, cfg.loopCapFps / (std::max)(1, cfg.overlayCapFps));
        overlayCounter++;
        if (overlayCounter >= overlaySkip) {
            overlayCounter = 0;

            ImGui::SetCurrentContext(overlayCtx);
            ImGui_ImplDX11_NewFrame();
            ImGui_ImplWin32_NewFrame();
            ImGui::NewFrame();

            ImDrawList* ovlDraw = ImGui::GetBackgroundDrawList();
            renderer.draw(ovlDraw, screenCx, screenCy,
                           cfg.aim.fovRadius, activeTargetId, cfg.render);

            ImGui::Render();

            const float clear[4] = {0.f, 0.f, 0.f, 0.f};
            overlayD3D.devCtx->OMSetRenderTargets(1, &overlayD3D.rtv, nullptr);
            overlayD3D.devCtx->ClearRenderTargetView(overlayD3D.rtv, clear);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
            overlayD3D.swapChain->Present(0, 0);
        }

        // ════════════════════════════════════════════════════════════
        //  MENU: dynamic FPS cap from config
        // ════════════════════════════════════════════════════════════
        int menuSkip = (std::max)(1, cfg.loopCapFps / (std::max)(1, cfg.menuCapFps));
        menuCounter++;
        if (menuCounter >= menuSkip) {
            menuCounter = 0;

            ImGui::SetCurrentContext(menuCtx);
            ImGui_ImplDX11_NewFrame();
            ImGui_ImplWin32_NewFrame();
            ImGui::NewFrame();

            bool modelOk = g_modelReady.load();
            bool needReload = uiPanel.draw(cfg, renderFps, g_inferFps,
                                             gpuList, modelOk);
            if (needReload) reloadFlag = true;

            ImGui::Render();

            const float dark[4] = {0.051f, 0.051f, 0.051f, 1.0f};
            menuD3D.devCtx->OMSetRenderTargets(1, &menuD3D.rtv, nullptr);
            menuD3D.devCtx->ClearRenderTargetView(menuD3D.rtv, dark);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
            menuD3D.swapChain->Present(0, 0);  // NO vsync — don't block!
        }

        // ── FPS counter ──────────────────────────────────────────────
        fpsAccum += dt;
        frameCount++;
        if (fpsAccum >= 0.5f) {
            renderFps = frameCount / fpsAccum;
            frameCount = 0; fpsAccum = 0.f;
        }

        // ── Dynamic main loop FPS cap ─────────────────────────────────
        int loopCap = (std::max)(30, (std::min)(cfg.loopCapFps, 500));
        auto targetFrameTime = std::chrono::microseconds(1000000 / loopCap);
        auto elapsed = std::chrono::high_resolution_clock::now() - loopStart;
        if (elapsed < targetFrameTime) {
            auto remaining = targetFrameTime - elapsed;
            auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(remaining);
            if (ms.count() > 0) Sleep(static_cast<DWORD>(ms.count()));
        }
    }

    // ── Shutdown ──────────────────────────────────────────────────────
    g_running = false;
    if (ciThread.joinable()) ciThread.join();

    ImGui::SetCurrentContext(overlayCtx);
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext(overlayCtx);

    ImGui::SetCurrentContext(menuCtx);
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext(menuCtx);

    overlayD3D.releaseAll();
    menuD3D.releaseAll();

    DestroyWindow(overlayHwnd);
    DestroyWindow(menuHwnd);
    return 0;
}
